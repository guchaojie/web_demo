#!/bin/sh
if [ $# -ne 1 ]; then
	echo "usage: ./scp.sh ip"
	exit 0
fi

REMOTE=root@$1

scp *.xml ${REMOTE}:/usr/etc/
scp build/src/server/sensord  build/test/sensor-test build/test/api-test   ${REMOTE}:/usr/bin/

scp build/src/shared/libsensord-s* build/src/libsensord/libsensor.so* ${REMOTE}:/usr/lib/

scp build/src/light/liblight_sensor*  build/src/temperature/libtemperature_sensor* build/src/misc/libmisc_sensor* build/src/pressure/libpressure_sensor*  build/src/geo/libgeo_sensor* build/src/gyro/libgyro_sensor*  build/src/accel/libaccel_sensor* ${REMOTE}:/usr/lib/sensord/

