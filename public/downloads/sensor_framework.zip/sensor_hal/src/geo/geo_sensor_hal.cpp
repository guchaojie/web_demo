/*
 * geo_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <linux/input.h>
#include <csensor_config.h>
#include <geo_sensor_hal.h>
#include <sys/ioctl.h>
#include <sys/poll.h>
#include <fstream>

using std::ifstream;

geo_sensor_hal::geo_sensor_hal(string &name)
: m_x(0)
, m_y(0)
, m_z(0)
, m_hdst(0)
, m_fired_time(0)
, m_node_handle(-1)
, m_polling_interval(POLL_1HZ_MS)
{
	csensor_config &config = csensor_config::get_instance();

	node_info_query query;
	node_info info;

	m_model_id = name;
	DBG("%s find [%s]", __FUNCTION__, m_model_id.c_str());

	query.sensor_type = SENSOR_TYPE_MAGNETIC;
	query.key = m_model_id; //"geomagnetic_sensor";
	query.iio_enable_node_name = "geomagnetic_enable";

	bool error = get_node_info(query, info);

	query.key = "magnetic_sensor";
	error |= get_node_info(query, info);
	show_node_info(info);

	if (error) {
		m_data_node = info.data_node_path;
		m_enable_node = info.enable_node_path;
		m_interval_node = info.interval_node_path;
	} else {
		ERR("Failed to get node info");
	}


	if (!config.get(SENSOR_TYPE_MAGNETIC, m_model_id, ELEMENT_VENDOR, m_vendor)) {
		ERR("[VENDOR] is empty\n");
	}

	INFO("m_vendor = %s", m_vendor.c_str());

	if (!config.get(SENSOR_TYPE_MAGNETIC, m_model_id, ELEMENT_NAME, m_chip_name)) {
		m_chip_name = m_model_id;
		ERR("[NAME] is empty\n");
	}

	INFO("m_chip_name = %s\n",m_chip_name.c_str());

	double min_range;

	if (!config.get(SENSOR_TYPE_MAGNETIC, m_model_id, ELEMENT_MIN_RANGE, min_range)) {
		ERR("[MIN_RANGE] is empty\n");
	}

	m_min_range = (float)min_range;
	INFO("m_min_range = %f\n",m_min_range);

	double max_range;

	if (!config.get(SENSOR_TYPE_MAGNETIC, m_model_id, ELEMENT_MAX_RANGE, max_range)) {
		ERR("[MAX_RANGE] is empty\n");
	}

	m_max_range = (float)max_range;
	INFO("m_max_range = %f\n",m_max_range);

	double raw_data_unit;

	if (!config.get(SENSOR_TYPE_MAGNETIC, m_model_id, ELEMENT_RAW_DATA_UNIT, raw_data_unit)) {
		ERR("[RAW_DATA_UNIT] is empty\n");
	}

	m_raw_data_unit = (float)(raw_data_unit);

	if ((m_node_handle = open(m_data_node.c_str(),O_RDWR)) < 0) {
		ERR("Failed to open %s handle(%d)", m_data_node.c_str(), m_node_handle);
	}

#if 0
	int clockId = CLOCK_MONOTONIC;
	if (ioctl(m_node_handle, EVIOCSCLOCKID, &clockId) != 0)
		ERR("Fail to set monotonic timestamp for %s", m_data_node.c_str());
#endif

	INFO("m_raw_data_unit = %f\n", m_raw_data_unit);
	INFO("geo_sensor_hal is created!\n");

	set_iio_trigger_node(info.trigger_node_path, m_trigger_node, m_trigger_type);

	if (!info.buffer_enable_node_path.empty()) {
		set_node_value(info.buffer_enable_node_path, 0);
		set_node_value(info.base_dir + "/scan_elements/in_magn_x_en", 1);
		set_node_value(info.base_dir + "/scan_elements/in_magn_y_en", 1);
		set_node_value(info.base_dir + "/scan_elements/in_magn_z_en", 1);
		set_node_value(info.base_dir + "/scan_elements/in_timestamp_en", 1);
		set_node_value(info.buffer_length_node_path, 480);
		set_node_value(info.buffer_enable_node_path, 1);
	}
}

geo_sensor_hal::~geo_sensor_hal()
{
	close(m_node_handle);
	m_node_handle = -1;

	INFO("geo_sensor is destroyed!\n");
}

string geo_sensor_hal::get_model_id(void)
{
	return m_model_id;
}

sensor_type_id_t geo_sensor_hal::get_type(void)
{
	return GEOMAGNETIC_SENSOR;
}

bool geo_sensor_hal::enable(void)
{
	AUTOLOCK(m_mutex);

	set_enable_node(m_enable_node, true);
	set_interval(m_polling_interval);

	m_fired_time = 0;
	INFO("%s Geo sensor real starting", __func__);
	return true;
}

bool geo_sensor_hal::disable(void)
{
	AUTOLOCK(m_mutex);

	set_enable_node(m_enable_node, false);

	INFO("Geo sensor real stopping");
	return true;
}

bool geo_sensor_hal::set_interval(unsigned long val)
{
	unsigned long long polling_interval_ns;

	AUTOLOCK(m_mutex);

	polling_interval_ns = ((unsigned long long)(val) * 1000llu * 1000llu);

	if (!set_node_value(m_interval_node, polling_interval_ns)) {
		ERR("Failed to set polling resource: %s\n", m_interval_node.c_str());
		return false;
	}

	INFO("Interval is changed from %dms to %dms]", m_polling_interval, val);
	m_polling_interval = val;
	return true;

}
#if 1
// IIO event
bool geo_sensor_hal::update_value(bool wait)
{
		const int READ_LEN = 64;
		char data[READ_LEN] = {0,};

		struct pollfd pfd;

		pfd.fd = m_node_handle;
		pfd.events = POLLIN | POLLERR;
		pfd.revents = 0;

		if (m_trigger_type == IIO_TRIGGER_MANUAL) {
			set_node_value(m_trigger_node, 1);
		}

		ERR("%s poll... wait=%d\n", __FUNCTION__, wait);

		int ret = poll(&pfd, 1, -1);

		DBG("%s poll ret=%d\n", __FUNCTION__, ret);

		if (ret == -1) {
			ERR("poll error:%s m_node_handle:d", strerror(errno), m_node_handle);
			return false;
		} else if (!ret) {
			ERR("poll timeout m_node_handle:%d", m_node_handle);
			return false;
		}

		if (pfd.revents & POLLERR) {
			ERR("poll exception occurred! m_node_handle:%d", m_node_handle);
			return false;
		}

		if (!(pfd.revents & POLLIN)) {
			ERR("poll nothing to read! m_node_handle:%d, pfd.revents = %d", m_node_handle, pfd.revents);
			return false;
		}

		int len = read(m_node_handle, data, sizeof(data));
		if (len == -1) {
			DBG("Failed to read data, m_node_handle:%d read_len:%d", m_node_handle, len);
			return false;
		}
		DBG("%s read len=%d data=%d\n", __FUNCTION__, len, sizeof(data));

		if (len != sizeof(data)) {
			DBG("Failed to read data, m_node_handle:%d read_len:%d", m_node_handle, len);
			//return false;
		}

		AUTOLOCK(m_value_mutex);

		short *short_data = (short *)(data);
		m_x = *(short_data);
		m_y = *((short *)(data + 2));
		m_z = *((short *)(data + 4));

		m_fired_time = *((long long*)(data + 6));

		DBG("%s fired_time=%llu us", __func__, m_fired_time);
		return true;
}
#else
// INPUT event
bool geo_sensor_hal::update_value(bool wait)
{
	int geo_raw[4] = {0,};
	bool x,y,z,hdst;
	int read_input_cnt = 0;
	const int INPUT_MAX_BEFORE_SYN = 10;
	unsigned long long fired_time = 0;
	bool syn = false;

	x = y = z = hdst = false;

	struct input_event geo_input;
	DBG("geo event detection!");

	while ((syn == false) && (read_input_cnt < INPUT_MAX_BEFORE_SYN)) {
		int len = read(m_node_handle, &geo_input, sizeof(geo_input));
		if (len != sizeof(geo_input)) {
			ERR("geo_file read fail, read_len = %d\n",len);
			return false;
		}

		++read_input_cnt;

		if (geo_input.type == EV_REL) {
			switch (geo_input.code) {
				case REL_RX:
					geo_raw[0] = (int)geo_input.value;
					x = true;
					break;
				case REL_RY:
					geo_raw[1] = (int)geo_input.value;
					y = true;
					break;
				case REL_RZ:
					geo_raw[2] = (int)geo_input.value;
					z = true;
					break;
				case REL_HWHEEL:
					geo_raw[3] = (int)geo_input.value;
					hdst = true;
					break;
				default:
					ERR("geo_input event[type = %d, code = %d] is unknown.", geo_input.type, geo_input.code);
					return false;
					break;
			}
		} else if (geo_input.type == EV_SYN) {
			syn = true;
			fired_time = get_timestamp(&geo_input.time);
		} else {
			ERR("geo_input event[type = %d, code = %d] is unknown.", geo_input.type, geo_input.code);
			return false;
		}
	}

	AUTOLOCK(m_value_mutex);

	if (x)
		m_x =  geo_raw[0];
	if (y)
		m_y =  geo_raw[1];
	if (z)
		m_z =  geo_raw[2];
	if (hdst)
		m_hdst = geo_raw[3] - 1; /* accuracy bias: -1 */

	m_fired_time = fired_time;

	DBG("m_x = %d, m_y = %d, m_z = %d, m_hdst = %d, time = %lluus", m_x, m_y, m_z, m_hdst, m_fired_time);

	return true;
}
#endif

bool geo_sensor_hal::is_data_ready(bool wait)
{
	bool ret;

	DBG("%s", __func__);

	ret = update_value(wait);
	return ret;
}

int geo_sensor_hal::get_sensor_data(sensor_data_t &data)
{
	AUTOLOCK(m_value_mutex);

	DBG("%s m_set_data=%p", __func__, m_set_data);

	if (m_set_data) {
		DBG("Use fake data count=%d timestamp=%llu", m_set_data->value_count, m_set_data->timestamp);
		data.timestamp = m_set_data->timestamp;
		data.value_count = m_set_data->value_count;
		memcpy(data.values, m_set_data->values,
		sizeof(m_set_data->values[0]) * m_set_data->value_count);
		DBG("%s return 1 timestamp=%llu", __func__, data.timestamp);
		return 1;
	}

	data.accuracy = (m_hdst == 1) ? 0 : m_hdst; /* hdst 0 and 1 are needed to calibrate */
	data.timestamp = m_fired_time;
	data.value_count = 3;
	data.values[0] = (float)m_x;
	data.values[1] = (float)m_y;
	data.values[2] = (float)m_z;

	DBG("%s return 0 timestamp=%llu", __func__, data.timestamp);
	return 0;
}

bool geo_sensor_hal::free_set_data()
{
	AUTOLOCK(m_value_mutex);
	DBG("%s m_set_data=%p", __func__, m_set_data);
	if (m_set_data)
		free(m_set_data);

	m_set_data = NULL;

	return true;
}

bool geo_sensor_hal::get_properties(sensor_properties_s &properties)
{
	properties.name = m_chip_name;
	properties.vendor = m_vendor;
	properties.min_range = m_min_range;
	properties.max_range = m_max_range;
	properties.min_interval = 1;
	properties.resolution = m_raw_data_unit;
	properties.fifo_count = 0;
	properties.max_batch_count = 0;
	return true;
}

extern "C" sensor_module* create(string &name)
{
	geo_sensor_hal *sensor;

	try {
		sensor = new(std::nothrow) geo_sensor_hal(name);
	} catch (int err) {
		ERR("Failed to create module, err: %d, cause: %s", err, strerror(err));
		return NULL;
	}

	sensor_module *module = new(std::nothrow) sensor_module;
	retvm_if(!module || !sensor, NULL, "Failed to allocate memory");

	module->sensors.push_back(sensor);
	return module;
}
