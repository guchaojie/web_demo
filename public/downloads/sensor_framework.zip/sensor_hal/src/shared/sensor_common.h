/*
 * libsensord-share
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef __SENSOR_COMMON_H__
#define __SENSOR_COMMON_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup SENSOR_FRAMEWORK SensorFW
 * To support the unified API for the various sensors
 */

/**
 * @defgroup SENSOR_FRAMEWORK_COMMON Sensor Framework Common API
 * @ingroup SENSOR_FRAMEWORK
 *
 * These APIs are used to control the sensors.
 * @{
 */

#define PUBLIC_PRIVILEGE_LIST "http://iotlinux.org/privilege/sensord"
#define INTERNAL_PRIVILEGE_LIST "http://iotlinux.org/privilege/sensord.admin"

#define SENSOR_DATA_VALUE_SIZE 16
#define SENSOR_TYPE_NAME_SIZE  25
#define SENSOR_NAME_SIZE 16

typedef enum {
	ALL_SENSOR = -1,
	UNKNOWN_SENSOR = 0,
	ACCELEROMETER_SENSOR,
	GEOMAGNETIC_SENSOR,
	LIGHT_SENSOR,
	PROXIMITY_SENSOR,
	THERMOMETER_SENSOR,
	GYROSCOPE_SENSOR,
	PRESSURE_SENSOR,
	MOTION_SENSOR,
	FUSION_SENSOR,
	PEDOMETER_SENSOR,
	CONTEXT_SENSOR,
	FLAT_SENSOR,
	BIO_SENSOR,
	BIO_HRM_SENSOR,
	AUTO_ROTATION_SENSOR,
	GRAVITY_SENSOR,
	LINEAR_ACCEL_SENSOR,
	ROTATION_VECTOR_SENSOR,
	GEOMAGNETIC_RV_SENSOR,
	GAMING_RV_SENSOR,
	ORIENTATION_SENSOR,
	PIR_SENSOR,
	PIR_LONG_SENSOR,
	TEMPERATURE_SENSOR,
	HUMIDITY_SENSOR,
	ULTRAVIOLET_SENSOR,
	DUST_SENSOR,
	BIO_LED_GREEN_SENSOR,
	BIO_LED_IR_SENSOR,
	BIO_LED_RED_SENSOR,
	RV_RAW_SENSOR,
	UNCAL_GYROSCOPE_SENSOR,
	UNCAL_GEOMAGNETIC_SENSOR,
	MISC_SENSOR
} sensor_type_support_t;

typedef unsigned int sensor_id_t;
typedef unsigned int hal_id_t;

typedef int sensor_type_id_t;
typedef int sf_sensor_type_id_t;
typedef unsigned int sf_sensor_id_t;

typedef struct sf_sensor_type_s{
    sf_sensor_type_id_t sensor_type_id;
    char sensor_type[SENSOR_TYPE_NAME_SIZE];
} sf_sensor_type_t;

typedef void *sensor_t;

typedef enum {
	SENSOR_PRIVILEGE_NONE,
	SENSOR_PRIVILEGE_PUBLIC,
	SENSOR_PRIVILEGE_INTERNAL,
} sensor_privilege_t;


/*
 *	When modifying it, check copy_sensor_data()
 */
typedef struct sensor_data_t {
	int accuracy;
	unsigned long long timestamp;
	int value_count;
	float values[SENSOR_DATA_VALUE_SIZE];
} sensor_data_t;

enum sensor_accuracy_t {
	SENSOR_ACCURACY_UNDEFINED = -1,
	SENSOR_ACCURACY_BAD = 0,
	SENSOR_ACCURACY_NORMAL =1,
	SENSOR_ACCURACY_GOOD = 2,
	SENSOR_ACCURACY_VERYGOOD = 3
};

/*
 *	To prevent naming confliction as using same enums as sensor CAPI use
 */
#ifndef __SENSOR_H__
enum sensor_option_t {
	SENSOR_OPTION_DEFAULT = 0,
	SENSOR_OPTION_ON_IN_SCREEN_OFF = 1,
	SENSOR_OPTION_ON_IN_POWERSAVE_MODE = 2,
	SENSOR_OPTION_ALWAYS_ON = SENSOR_OPTION_ON_IN_SCREEN_OFF | SENSOR_OPTION_ON_IN_POWERSAVE_MODE,
	SENSOR_OPTION_END
};

typedef enum sensor_option_t sensor_option_e;
#endif

enum sensor_interval_t {
	SENSOR_INTERVAL_FASTEST = 0,
	SENSOR_INTERVAL_NORMAL = 200,
};


typedef enum {
	CONDITION_NO_OP,
	CONDITION_EQUAL,
	CONDITION_GREAT_THAN,
	CONDITION_LESS_THAN,
} condition_op_t;

#ifdef __cplusplus
}
#endif


#endif
//! End of a file
