/*
 * libsensord-share
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#if !defined(_SENSOR_PLUGIN_LOADER_CLASS_H_)
#define _SENSOR_PLUGIN_LOADER_CLASS_H_

#include <sensor_common.h>

#include <cmutex.h>
#include <sstream>

#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <unordered_set>


class sensor_hal;
class sensor_base;

using std::pair;
using std::vector;
using std::multimap;
using std::map;
using std::unordered_map;
using std::unordered_set;
using std::string;
using std::istringstream;

typedef multimap<sensor_type_id_t, sensor_hal*> sensor_hal_modules;
/*
* a hal_plugins is a group of hal plugin
* <HAL>
* ...
* </HAL>
*
*/

typedef multimap<sensor_type_id_t, sensor_base*> sensor_modules;
/*
* a sensor_modules is a group of sensor plugin
* <SENSOR>
* ...
* </SENSOR>
*
*/
typedef map<string, string> sensor_plugins;
/*
 * ACCELEROMETER_SENSOR	--- libxxx.so
 *	...
 */

typedef unordered_set<unsigned int> id_set;

typedef enum plugin_type {
		PLUGIN_TYPE_HAL,
		PLUGIN_TYPE_SENSOR,
	} plugin_type;

class sensor_plugin_loader
{
private:
	sensor_plugin_loader();

	bool load_module(const string &name, const string &path, vector<void*> &sensors, void* &handle);
	void show_sensor_info(void);
	bool get_paths_from_config(const string &config_path);

	bool set_sensor_type_map(void);
	bool check_available_i2c_sensor(const string &model_id);

	sensor_hal_modules m_sensor_hals;
	sensor_modules m_sensors;

	sensor_plugins m_hal_plugins;
	sensor_plugins m_sensor_plugins;

	id_set m_sensor_ids;
	id_set m_hal_ids;

public:	
	static sensor_plugin_loader& get_instance();
	bool load_plugins(void);

	sensor_hal* get_sensor_hal(sensor_type_id_t type, hal_id_t hal_id);
	vector<sensor_hal *> get_sensor_hals(sensor_type_id_t type);

	sensor_base* get_sensor(sensor_type_id_t type);
	vector<sensor_base *> get_sensors(sensor_type_id_t type);
	sensor_base* get_sensor(sensor_id_t id);
	bool del_sensor(sensor_id_t id);
	bool insert_hal_module(const string &name, const string &path, hal_id_t &hal_id);
	bool get_plugins(string sensor_type, string &hal, string &sensor);
	bool insert_sensor_module(const string &name, const string &path, hal_id_t hal_id, sensor_id_t &id);

	vector<sensor_base*> get_virtual_sensors(void);

	bool destroy();
};
#endif	/* _SENSOR_PLUGIN_LOADER_CLASS_H_ */
