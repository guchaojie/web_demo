/*
 * libsensord-share
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <sensor_hal.h>
#include <dirent.h>
#include <string.h>
#include <fstream>
#include <csensor_config.h>
#include <mraa.h>

using std::ifstream;
using std::fstream;

cmutex sensor_hal::m_shared_mutex;

sensor_hal::sensor_hal()
: m_set_data(NULL)
{
	m_bus = -1;
	m_address = -1;
	m_register = -1;
}

sensor_hal::~sensor_hal()
{
}

bool sensor_hal::init(void *data)
{
	return true;
}

bool sensor_hal::set_interval(unsigned long val)
{
	return true;
}

long sensor_hal::set_command(unsigned int cmd, long val)
{
	return -1;
}

int sensor_hal::get_sensor_data(sensor_data_t &data)
{
	return -1;
}

int sensor_hal::get_sensor_raw_data(unsigned char *data, unsigned int &size)
{
	mraa_i2c_context i2c;
	AUTOLOCK(m_mutex);

	DBG("+%s len=%d", __FUNCTION__, size);
	i2c = mraa_i2c_init(m_bus);
	mraa_i2c_address(i2c, m_address);
	size = mraa_i2c_read_bytes_data(i2c, m_register, data, size);

	return 0;
}

int sensor_hal::set_sensor_data(sensor_data_t data)
{
	AUTOLOCK(m_mutex);

	DBG("%s m_set_data=%p count=%d", __func__, m_set_data, data.value_count);

	if (m_set_data)
		return -1;

	m_set_data = (sensor_data_t *)malloc(sizeof(sensor_data_t));

	m_set_data->timestamp = data.timestamp;
	m_set_data->value_count = data.value_count;

	memcpy(m_set_data->values, data.values,
		sizeof(m_set_data->values[0]) * m_set_data->value_count);

	DBG("%s m_set_data=%p count=%d timestamp=%llu", __func__, m_set_data, data.value_count, data.timestamp);

	return 0;
}

bool sensor_hal::free_set_data()
{
	DBG("%s", __func__);
	return true;
}

int sensor_hal::set_read_method(sf_sensor_hw_t hw_info)
{
	DBG("%s 0x%x-0x%x-0x%x", __func__, hw_info.bus_num, hw_info.sensor_address, hw_info.sensor_register);
	DBG("m_bus=%d m_address=%d m_address=%d", m_bus, m_address, m_register);

	AUTOLOCK(m_mutex);

	m_bus = hw_info.bus_num;
	m_address = hw_info.sensor_address;
	m_register = hw_info.sensor_register;

	return 0;
}

unsigned long long sensor_hal::get_timestamp(void)
{
	struct timespec t;
	clock_gettime(CLOCK_MONOTONIC, &t);
	return ((unsigned long long)(t.tv_sec)*1000000000LL + t.tv_nsec) / 1000;
}

unsigned long long sensor_hal::get_timestamp(timeval *t)
{
	if (!t) {
		ERR("t is NULL");
		return 0;
	}

	return ((unsigned long long)(t->tv_sec)*1000000LL +t->tv_usec);
}

bool sensor_hal::get_node_info(const node_info_query &query, node_info &info)
{
	bool ret = false;
	int method;
	string device_num;

	if (!get_input_method(query.key, method, device_num)) {
		ERR("Failed to get input method for %s", query.key.c_str());
		return false;
	}

	info.method = method;
	info.sensor_type = query.sensor_type;

	DBG("%s %s method=%d device_num=%s", __FUNCTION__, query.key.c_str(), method, device_num.c_str());

	if (method == I2C_METHOD) {
		ret = get_i2c_node_info(query.iio_enable_node_name, device_num, info);

	} else if (method == IIO_METHOD) {
			ret = get_iio_node_info(query.iio_enable_node_name, device_num, info);
	} else if (method == INPUT_EVENT_METHOD) {
			ret = get_input_event_node_info(device_num, info);
	} else {
		ERR("%s incorrect method %d", __FUNCTION__, method);
		ret = false;
	}

	return ret;
}

void sensor_hal::show_node_info(node_info &info)
{
	INFO("%s Method: %d", __FUNCTION__, info.method);

	if (info.data_node_path.size())
		INFO("Data node: %s", info.data_node_path.c_str());
	if (info.base_dir.size())
		INFO("Base dir: %s", info.base_dir.c_str());
	if (info.enable_node_path.size())
		INFO("Enable node: %s", info.enable_node_path.c_str());
	if (info.interval_node_path.size())
		INFO("Interval node: %s", info.interval_node_path.c_str());
	if (info.buffer_enable_node_path.size())
		INFO("Buffer enable node: %s", info.buffer_enable_node_path.c_str());
	if (info.buffer_length_node_path.size())
		INFO("Buffer length node: %s", info.buffer_length_node_path.c_str());
	if (info.trigger_node_path.size())
		INFO("Trigger node: %s", info.trigger_node_path.c_str());
}

bool sensor_hal::get_iio_node_info(const string& enable_node_name, const string& device_num, node_info &info)
{
	const string base_dir = string("/sys/bus/iio/devices/iio:device") + device_num + string("/");

	info.data_node_path = string("/dev/iio:device") + device_num;
	info.base_dir = base_dir;
	info.enable_node_path = base_dir + enable_node_name;
	info.interval_node_path = base_dir + string("sampling_frequency");
	info.buffer_enable_node_path = base_dir + string("buffer/enable");
	info.buffer_length_node_path = base_dir + string("buffer/length");
	info.trigger_node_path = base_dir + string("trigger/current_trigger");
	return true;
}

bool sensor_hal::get_i2c_node_info(const string& enable_node_name, const string& device_num, node_info &info)
{
	string name_node, name;
	string d_name;
	DIR *dir = NULL;
	struct dirent *dir_entry = NULL;
	bool find = false;
	const string base_dir = string("/sys/bus/i2c/devices/") + device_num + string("/");

	info.base_dir = base_dir;

	DBG("%s device_num=%s base_dir=%s sensor_type=%s",
		__FUNCTION__, device_num.c_str(), base_dir.c_str(), info.sensor_type.c_str());

	dir = opendir(base_dir.c_str());
	if (!dir) {
		ERR("Failed to open dir: %s", base_dir.c_str());
		return false;
	}

	while (!find && (dir_entry = readdir(dir))) {
		d_name = string(dir_entry->d_name);
		DBG("d_name=%s", d_name.c_str());

		if ((d_name != ".") && (d_name != "..") && (dir_entry->d_ino != 0)) {
			if (d_name.compare(0, info.sensor_type.size(), info.sensor_type) == 0) {
				find = true;
				info.data_node_path = base_dir + d_name;
				DBG("Find data node [%s]", info.data_node_path.c_str());
				break;
			}
		}
	}

	closedir(dir);

	return true;
}

bool sensor_hal::get_input_event_node_info(const string& device_num, node_info &info)
{
	string base_dir;
	string event_num;

	base_dir = string("/sys/class/input/input") + device_num + string("/");

	if (!get_event_num(base_dir, event_num))
		return false;

	info.base_dir = base_dir;
	info.data_node_path = string("/dev/input/event") + event_num;

	info.enable_node_path = base_dir + string("enable");
	info.interval_node_path = base_dir + string("poll_delay");
	return true;
}

bool sensor_hal::set_node_value(const string &node_path, int value)
{
	fstream node(node_path, fstream::out);

	if (!node)
		return false;

	node << value;

	return true;
}

bool sensor_hal::set_node_value(const string &node_path, string value)
{
	fstream node(node_path, fstream::out);

	if (!node)
		return false;

	node << value;

	return true;
}

bool sensor_hal::set_node_value(const string &node_path, unsigned long long value)
{
	fstream node(node_path, fstream::out);

	if (!node)
		return false;

	node << value;

	return true;
}


bool sensor_hal::get_node_value(const string &node_path, int &value)
{
	fstream node(node_path, fstream::in);

	if (!node)
		return false;

	node >> value;

	return true;
}

bool sensor_hal::get_node_value(const string &node_path, string &value)
{
	fstream node(node_path, fstream::in);

	if (!node)
		return false;

	node >> value;

	return true;
}

bool sensor_hal::set_enable_node(const string &node_path, bool enable)
{
	int prev_status, status;

	AUTOLOCK(m_shared_mutex);

	if (!get_node_value(node_path, prev_status)) {
		ERR("Failed to get node: %s", node_path.c_str());
		return false;
	}

	if (enable)
		status = prev_status | (1 << 0);
	else
		status = prev_status & (~(1 << 0));

	if (!set_node_value(node_path, status)) {
		ERR("Failed to set node: %s", node_path.c_str());
		return false;
	}

	return true;
}

bool sensor_hal::set_iio_trigger_node(const string &trig_path, string &trig_node,
				      int &trig_type)
{
	string trigger;
	string addtrigger = "/sys/bus/iio/devices/iio_sysfs_trigger/add_trigger";
	string systrigger = "sysfstrig";
	string num;

	DBG("+%s trig_path=%s trig_node=%s", __FUNCTION__, trig_path.c_str(), trig_node.c_str());
	get_node_value(trig_path, trigger);

	DBG("+%s trig_path=%s trig=%s", __FUNCTION__, trig_path.c_str(), trigger.c_str());

	if (trigger.size() == 0) {
		/* no interrupt, need to trigger manually every time when getting data */
		trig_type = IIO_TRIGGER_MANUAL;
		if (get_iio_available_trigger(trigger, num)) {
			set_node_value(addtrigger, num);
			set_node_value(trig_path, trigger);

			DBG("trigger=%s", trigger.c_str());

			trig_node = "/sys/bus/iio/devices/iio_sysfs_trigger/trigger" \
						 + num + "/trigger_now";
		} else {
			ERR("Failed to find an available trriger node");
			return false;
		}
	} else if (trigger.compare(0, systrigger.size(), systrigger) == 0) {
		num = trigger.substr(systrigger.size(), trigger.size() - systrigger.size());
		trig_node = "/sys/bus/iio/devices/iio_sysfs_trigger/trigger" + num + "/trigger_now";
		trig_type = IIO_TRIGGER_MANUAL;
	} else {	/* can be auto triggered by driver interrupt */
		trig_type = IIO_TRIGGER_AUTO;
	}

	return true;
}


bool sensor_hal::find_model_id(const string &sensor_type, string &model_id)
{
	string dir_path = "/sys/bus/i2c/devices/";
	//string dir_path = "/sys/class/sensors/";
	string name_node, name;
	string d_name;
	DIR *dir = NULL;
	struct dirent *dir_entry = NULL;
	bool find = false;

	dir = opendir(dir_path.c_str());
	if (!dir) {
		DBG("Failed to open dir: %s", dir_path.c_str());
		return false;
	}

	while (!find && (dir_entry = readdir(dir))) {
		d_name = string(dir_entry->d_name);

		if ((d_name != ".") && (d_name != "..") && (dir_entry->d_ino != 0)) {
			name_node = dir_path + d_name + string("/name");

			ifstream infile(name_node.c_str());

			if (!infile)
				continue;

			infile >> name;

			if (csensor_config::get_instance().is_supported(sensor_type, name)) {
				model_id = name;
				find = true;
				break;
			}
		}
	}

	closedir(dir);

	return find;
}

bool sensor_hal::get_event_num(const string &input_path, string &event_num)
{
	const string event_prefix = "event";
	DIR *dir = NULL;
	struct dirent *dir_entry = NULL;
	string node_name;
	bool find = false;

	dir = opendir(input_path.c_str());
	if (!dir) {
		ERR("Failed to open dir: %s", input_path.c_str());
		return false;
	}

	int prefix_size = event_prefix.size();

	while (!find && (dir_entry = readdir(dir))) {
		node_name = dir_entry->d_name;

		if (node_name.compare(0, prefix_size, event_prefix) == 0) {
			event_num = node_name.substr(prefix_size, node_name.size() - prefix_size);
			find = true;
			break;
		}
	}

	closedir(dir);

	return find;
}

void sensor_hal::set_hal_id(hal_id_t hal_id)
{
	m_hal_id = hal_id;
}

hal_id_t sensor_hal::get_hal_id(void)
{
	return m_hal_id;
}

bool sensor_hal::get_iio_available_trigger(string& trig_node, string &num)
{
	string trig_dir;
	DIR *dir;
	bool find = false;
	int i;
	char str[3] = {0,};

	for (i = 0; i < 128; i++) {
		sprintf(str, "%d", i);
		trig_dir = str;
		trig_dir = "/sys/bus/iio/devices/trigger" + trig_dir;

		dir = opendir(trig_dir.c_str());
		if (!dir) {
			find = true;
			num = str;
			trig_node = "sysfstrig" + num;
			break;
		} else {
			closedir(dir);
		}
	}

	return find;
}

bool sensor_hal::get_input_method(const string &key, int &method, string &device_num)
{
	input_method_info input_info[] = {
		{INPUT_EVENT_METHOD, "/sys/class/input/", "input"},
		{IIO_METHOD, "/sys/bus/iio/devices/", "iio:device"},
		{I2C_METHOD, "/sys/bus/i2c/devices/", ""},
	};

	const int input_info_len = sizeof(input_info)/sizeof(input_info[0]);
	size_t prefix_size;
	string name_node, name;
	string d_name;
	DIR *dir = NULL;
	struct dirent *dir_entry = NULL;
	bool find = false;

	for (int i = 0; i < input_info_len; ++i) {

		prefix_size = input_info[i].prefix.size();

		dir = opendir(input_info[i].dir_path.c_str());
		if (!dir) {
			ERR("Failed to open dir: %s", input_info[i].dir_path.c_str());
			continue;
		}

		find = false;

		while (!find && (dir_entry = readdir(dir))) {
			d_name = string(dir_entry->d_name);

			if ((d_name != ".") && (d_name != "..")
				&& (d_name.compare(0, prefix_size, input_info[i].prefix) == 0)) {
				name_node = input_info[i].dir_path + d_name + string("/name");

				ifstream infile(name_node.c_str());
				if (!infile)
					continue;

				infile >> name;

				if (name == key) {
					device_num = d_name.substr(prefix_size, d_name.size() - prefix_size);
					find = true;
					method = input_info[i].method;
					break;
				}
			}
		}

		closedir(dir);

		if (find)
			break;
	}

	return find;
}
