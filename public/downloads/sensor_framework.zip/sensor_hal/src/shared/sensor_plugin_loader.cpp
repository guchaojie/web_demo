/*
 * libsensord-share
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <sensor_plugin_loader.h>
#include <libxml/xmlmemory.h>
#include <libxml/parser.h>
#include <sensor_hal.h>
#include <sensor_base.h>
#include <csensor_config.h>
#include <dlfcn.h>
#include <dirent.h>
#include <common.h>
#include <unordered_set>
#include <algorithm>
#include <iostream>
#include <fstream>

using std::make_pair;
using std::equal;
using std::unordered_set;
using std::ifstream;

#define ROOT_ELEMENT "PLUGIN"
#define TEXT_ELEMENT "text"
#define MODULE_ELEMENT "MODULE"
#define HAL_ATTR "hal"
#define SENSOR_ATTR "sensor"

#define PLUGINS_CONFIG_PATH "/usr/etc/sensor_plugins.xml"
#define PLUGINS_DIR_PATH "/sensord"

#define SENSOR_INDEX_SHIFT 16

sensor_plugin_loader::sensor_plugin_loader()
{

}

bool sensor_plugin_loader::set_sensor_type_map()
{
	csensor_config &config = csensor_config::get_instance();
	Sensor_config &m_sensor_config = config.get_sensor_config();
	string hal, sensor;
	hal_id_t hal_id;
	sensor_id_t id;

	for (auto it_model_list = m_sensor_config.begin();
		  it_model_list != m_sensor_config.end(); ++it_model_list) {
		DBG("type = %s", it_model_list->first.c_str());
		auto model = it_model_list->second;
		for (auto it_model_id = model.begin(); it_model_id != model.end();
			  ++it_model_id) {
			DBG("id = %s", it_model_id->first.c_str());

			if ((it_model_list->first != string("MISC_SENSOR")) &&
			    (!check_available_i2c_sensor(it_model_id->first))) {
				ERR("Wrong xml config file or sensor is not exist!!");
				continue;
			}

			DBG("%s exist", it_model_id->first.c_str());
			if (!get_plugins(it_model_list->first, hal, sensor)) {
				ERR("no plugins for TYPE %s", it_model_list->first.c_str());
				continue;
			}

			if (!insert_hal_module(it_model_id->first, hal, hal_id))
				continue;

			insert_sensor_module(it_model_id->first, sensor, hal_id, id);
		}
	}

	return true;
}

bool sensor_plugin_loader::check_available_i2c_sensor(const string &model_id)
{
	string dir_path = "/sys/bus/i2c/devices/";
	string name_node, name;
	string d_name;
	DIR *dir = NULL;
	struct dirent *dir_entry = NULL;
	bool find = false;

	DBG("%s %s", __FUNCTION__, model_id.c_str());

	dir = opendir(dir_path.c_str());
	if (!dir) {
		DBG("Failed to open dir: %s", dir_path.c_str());
		return false;
	}

	while (!find && (dir_entry = readdir(dir))) {
		d_name = string(dir_entry->d_name);

		if ((d_name != ".") && (d_name != "..") && (dir_entry->d_ino != 0)) {
			name_node = dir_path + d_name + string("/name");

			ifstream infile(name_node.c_str());

			if (!infile)
				continue;

			infile >> name;

			if (model_id == name) {
				find = true;
				DBG("%s %s Found!", __FUNCTION__, model_id.c_str());
				break;
			}
		}
	}

	closedir(dir);

	return find;
}

sensor_plugin_loader& sensor_plugin_loader::get_instance()
{
	static sensor_plugin_loader inst;
	return inst;
}

bool sensor_plugin_loader::load_module(const string &name, const string &path,
				       vector<void*> &sensors, void* &handle)
{
	void *_handle = dlopen(path.c_str(), RTLD_NOW);

	if (!_handle) {
		ERR("Failed to dlopen(%s), dlerror : %s", path.c_str(), dlerror());
		return false;
	}

	dlerror();

	create_t create_module = (create_t) dlsym(_handle, "create");

	if (!create_module) {
		ERR("Failed to find symbols in %s", path.c_str());
		dlclose(_handle);
		return false;
	}

	DBG("%s create_module(%s)", __FUNCTION__, name.c_str());

	sensor_module *module = create_module(name);

	if (!module) {
		ERR("Failed to create module, path is %s\n", path.c_str());
		dlclose(_handle);
		return false;
	}

	sensors.clear();
	sensors.swap(module->sensors);

	delete module;
	handle = _handle;

	return true;
}

bool sensor_plugin_loader::insert_hal_module(const string &name, const string &path, hal_id_t &hal_id)
{
	DBG("Insert HAL plugin [%s] %s", path.c_str(), name.c_str());

	std::vector<void *>hals;
	void *handle;

	if (!load_module(name, path, hals, handle))
		return false;

	sensor_hal* hal;

	for (unsigned int i = 0; i < hals.size(); ++i) {
		hal = static_cast<sensor_hal*> (hals[i]);
		sensor_type_id_t sensor_type = hal->get_type();

		int id = 0;
		while (m_hal_ids.count(id << SENSOR_INDEX_SHIFT | sensor_type) > 0)
			id++;

		hal_id = id << SENSOR_INDEX_SHIFT | sensor_type;
		m_hal_ids.insert(id << SENSOR_INDEX_SHIFT | sensor_type);
		hal->set_hal_id(id << SENSOR_INDEX_SHIFT | sensor_type);
		m_sensor_hals.insert(make_pair(sensor_type, hal));
	}

	return true;
}

bool sensor_plugin_loader::insert_sensor_module(const string &name, const string &path,
				hal_id_t hal_id, sensor_id_t &id)
{

	DBG("Insert Sensor plugin [%s] %s", path.c_str(), name.c_str());

	std::vector<void *> sensors;
	void *handle;

	if (!load_module(name, path, sensors, handle))
		return false;

	sensor_base* sensor;

	for (unsigned int i = 0; i < sensors.size(); ++i) {
		sensor = static_cast<sensor_base*> (sensors[i]);

		if (!sensor->init(hal_id)) {
			m_hal_ids.erase(hal_id);
			ERR("Failed to init [%s] module\n", sensor->get_name());
			delete sensor;
			continue;
		}

		DBG("init [%s] module", sensor->get_name());

		sensor_type_id_t sensor_type = sensor->get_type();

		int idx = 0;

		while (m_sensor_ids.count(idx << SENSOR_INDEX_SHIFT | sensor_type) > 0)
			idx++;

		sensor->set_id(idx << SENSOR_INDEX_SHIFT | sensor_type);
		id = idx << SENSOR_INDEX_SHIFT | sensor_type;
		m_sensor_ids.insert(id);
		m_sensors.insert(make_pair(sensor_type, sensor));
	}

	return true;
}

bool sensor_plugin_loader::load_plugins(void)
{
	get_paths_from_config(string(PLUGINS_CONFIG_PATH));

	set_sensor_type_map();	

	show_sensor_info();
	return true;
}

bool sensor_plugin_loader::get_plugins(string sensor_type, string &hal, string &sensor)
{
	auto iter = m_hal_plugins.find(sensor_type);
	if (iter == m_hal_plugins.end())
		return false;
	else
		hal = iter->second;

	auto iter1 = m_sensor_plugins.find(sensor_type);
	if (iter1 == m_sensor_plugins.end())
		return false;
	else
		sensor = iter1->second;

	return true;
}

void sensor_plugin_loader::show_sensor_info(void)
{
	INFO("========== Loaded sensor information ==========\n");

	int index = 0;

	auto it = m_sensors.begin();

	while (it != m_sensors.end()) {
		sensor_base* sensor = it->second;

		sensor_info info;
		sensor->get_sensor_info(info);
		INFO("No:%d [%s]\n", ++index, sensor->get_name());
		info.show();
		it++;
	}

	INFO("===============================================\n");
}

bool sensor_plugin_loader::get_paths_from_config(const string &config_path)
{
	xmlDocPtr doc;
	xmlNodePtr cur;

	doc = xmlParseFile(config_path.c_str());

	if (doc == NULL) {
		ERR("There is no %s\n", config_path.c_str());
		return false;
	}

	cur = xmlDocGetRootElement(doc);

	if (cur == NULL) {
		ERR("There is no root element in %s\n", config_path.c_str());
		xmlFreeDoc(doc);
		return false;
	}

	if (xmlStrcmp(cur->name, (const xmlChar *)ROOT_ELEMENT)) {
		ERR("Wrong type document: there is no [%s] root element in %s\n", ROOT_ELEMENT, config_path.c_str());
		xmlFreeDoc(doc);
		return false;
	}

	xmlNodePtr plugin_list_node_ptr;
	xmlNodePtr module_node_ptr;
	xmlAttrPtr attr_ptr;
	char* prop = NULL;
	string path, category;

	plugin_list_node_ptr = cur->xmlChildrenNode;

	while (plugin_list_node_ptr != NULL) {
		//skip garbage element, [text]
		if (!xmlStrcmp(plugin_list_node_ptr->name, (const xmlChar *)TEXT_ELEMENT)) {
			plugin_list_node_ptr = plugin_list_node_ptr->next;
			continue;
		}

		DBG("<%s>\n", (const char*)plugin_list_node_ptr->name);

		module_node_ptr = plugin_list_node_ptr->xmlChildrenNode;
		while (module_node_ptr != NULL) {
			/* if not MODULE, skip */
			if (xmlStrcmp(module_node_ptr->name, (const xmlChar *)MODULE_ELEMENT)) {
				module_node_ptr = module_node_ptr->next;
				continue;
			}

			attr_ptr = module_node_ptr->properties;
			while (attr_ptr != NULL) {
				prop = (char*)xmlGetProp(module_node_ptr, attr_ptr->name);
				path = prop;
				free(prop);

				DBG("<%s %s=\"%s\">\n", (const char*) module_node_ptr->name,
							attr_ptr->name, path.c_str());

				category = (const char*) plugin_list_node_ptr->name;
				DBG("category = %s", category.c_str());

				if (strcmp((char *)attr_ptr->name, HAL_ATTR) == 0)
					m_hal_plugins.insert(make_pair(category, path));
				else if (strcmp((char *)attr_ptr->name, SENSOR_ATTR) == 0)
					m_sensor_plugins.insert(make_pair(category, path));

				attr_ptr = attr_ptr->next;
			}

			DBG("\n");
			module_node_ptr = module_node_ptr->next;
		}

		DBG("\n");
		plugin_list_node_ptr = plugin_list_node_ptr->next;
	}

	xmlFreeDoc(doc);

	return true;

}

sensor_hal* sensor_plugin_loader::get_sensor_hal(sensor_type_id_t type, hal_id_t hal_id)
{
	auto it_plugins = m_sensor_hals.find(type);
	int i;
	hal_id_t h_id;

	if (it_plugins == m_sensor_hals.end()) {
		return NULL;
	}
	else {
		for (i = 0; i != m_sensor_hals.count(type); i++, it_plugins++) {
			h_id = it_plugins->second->get_hal_id();

			if (hal_id == h_id)
			    break;
		}

		if (i == m_sensor_hals.count(type))
		    return NULL;
	}

	return it_plugins->second;
}

vector<sensor_hal *> sensor_plugin_loader::get_sensor_hals(sensor_type_id_t type)
{
	vector<sensor_hal *> sensor_hal_list;
	pair<sensor_hal_modules::iterator, sensor_hal_modules::iterator> ret;
	ret = m_sensor_hals.equal_range(type);

	for (auto it = ret.first; it != ret.second; ++it)
		sensor_hal_list.push_back(it->second);

	return sensor_hal_list;
}

sensor_base* sensor_plugin_loader::get_sensor(sensor_type_id_t type)
{
	auto it_plugins = m_sensors.find(type);

	if (it_plugins == m_sensors.end())
		return NULL;

	return it_plugins->second;
}

vector<sensor_base *> sensor_plugin_loader::get_sensors(sensor_type_id_t type)
{
	vector<sensor_base *> sensor_list;
	pair<sensor_modules::iterator, sensor_modules::iterator> ret;

	if (type == ALL_SENSOR)
		ret = std::make_pair(m_sensors.begin(), m_sensors.end());
	else
		ret = m_sensors.equal_range(type);

	for (auto it = ret.first; it != ret.second; ++it)
		sensor_list.push_back(it->second);

	return sensor_list;
}


sensor_base* sensor_plugin_loader::get_sensor(sensor_id_t id)
{
	const int SENSOR_TYPE_MASK = 0x0000FFFF;
	vector<sensor_base *> sensors;
	sensor_id_t s_id;

	sensor_type_id_t type = (sensor_type_id_t) (id & SENSOR_TYPE_MASK);
	unsigned int index = id >> SENSOR_INDEX_SHIFT;

	sensors = get_sensors(type);

	for (auto iter = sensors.begin(); iter != sensors.end(); ++iter) {
		s_id = (*iter)->get_id();
		if (s_id == id)
			return *iter;
	}

	return NULL;
}

bool sensor_plugin_loader::del_sensor(sensor_id_t id)
{
	sensor_base *m_module;
	sensor_hal *m_hal;
	const int SENSOR_TYPE_MASK = 0x0000FFFF;
	sensor_type_id_t type = (sensor_type_id_t) (id & SENSOR_TYPE_MASK);
	sensor_modules::iterator iter;
	sensor_hal_modules::iterator iter1;
	hal_id_t hal_id;

	m_module = get_sensor(id);
	if (!m_module)
		return false;

	DBG("count m_sensors is %d", m_sensors.size());
	for (iter = m_sensors.begin(); iter != m_sensors.end(); ++iter) {
		if (iter->second == m_module)
			break;		
	}

	if (iter == m_sensors.end())
		return false;


	hal_id = m_module->get_sensor_hal_id();

	DBG("count m_sensor_hal is %d", m_sensor_hals.size());

	m_hal = get_sensor_hal(type, hal_id);
	if (!m_hal)
		return false;

	for (iter1 = m_sensor_hals.begin(); iter1 != m_sensor_hals.end(); ++iter1) {
		if (iter1->second == m_hal)
			break;		
	}

	if (iter1 == m_sensor_hals.end())
		return false;

	m_sensors.erase(iter);
	m_sensor_hals.erase(iter1);
	m_sensor_ids.erase(id);
	m_hal_ids.erase(hal_id);

	DBG("count m_sensors is %d", m_sensors.size());
	DBG("count m_sensor_hal is %d", m_sensor_hals.size());

	return true;
}

vector<sensor_base *> sensor_plugin_loader::get_virtual_sensors(void)
{
	vector<sensor_base *> virtual_list;
	sensor_base* module;

	for (auto sensor_it = m_sensors.begin(); sensor_it != m_sensors.end(); ++sensor_it) {
		module = sensor_it->second;

		if (module && module->is_virtual() == true) {
			virtual_list.push_back(module);
		}
	}

	return virtual_list;
}

bool sensor_plugin_loader::destroy()
{
	sensor_base* sensor;

	for (auto sensor_it = m_sensors.begin(); sensor_it != m_sensors.end(); ++sensor_it) {
		sensor = sensor_it->second;

		//need to dlclose
		//unregister_module(module);

		delete sensor;
	}

	sensor_hal* sensor_hal;

	for (auto sensor_hal_it = m_sensor_hals.begin(); sensor_hal_it != m_sensor_hals.end(); ++sensor_hal_it) {
		sensor_hal = sensor_hal_it->second;

		// need to dlclose
		//unregister_module(module);

		delete sensor_hal;
	}

	m_sensors.clear();
	m_sensor_hals.clear();
	m_sensor_plugins.clear();
	m_hal_plugins.clear();
	m_sensor_ids.clear();
	m_hal_ids.clear();

	return true;
}

