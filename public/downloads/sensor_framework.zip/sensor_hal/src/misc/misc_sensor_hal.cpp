/*
 * temperature_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <csensor_config.h>
#include <misc_sensor_hal.h>
#include <sys/ioctl.h>

#define INITIAL_TIME -1

static struct misc_sensor_dev supported_misc_sensors[] = {
	{"bmpx8x", UPM_BMPX8X},
	{"mpl3115a2", UPM_MPL3115A2},
	{"mpu9150", UPM_MPU9150},

};

misc_sensor_hal::misc_sensor_hal(string &name)
: m_sensor(NULL)
, m_upm_sensor_type(UPM_UNKNOWN)
, m_polling_interval(POLL_1HZ_MS)
, m_fired_time(INITIAL_TIME)
{
	int i;
	string loadflag, bus, address;
	csensor_config &config = csensor_config::get_instance();

	m_model_id = name;
	DBG("+%s name=%s!", __FUNCTION__, m_model_id.c_str());

	// Get the info from XML
	if (!config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_NAME, m_chip_name)) {
		ERR("Cannot find %s in config file, is it a registered sensor?\n", name.c_str());
		m_chip_name = name;
	}

	if (true == config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_LOADED, loadflag)) {
		if (loadflag != string("1")) {
			DBG("loadflag != 1, skip load...");
			throw ENXIO;
		}
	} else {
		ERR("[LOADED] is empty");
	}

	for (i = 0; i < sizeof(supported_misc_sensors) / sizeof(supported_misc_sensors[0]); i++) {
			if (0 == strncmp(m_model_id.c_str(), supported_misc_sensors[i].sensor_name, m_model_id.size())) {
				m_upm_sensor_type = supported_misc_sensors[i].sensor_type;
				break;
			}
	}

	if (!config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_BUS, bus)) {
		ERR("[BUS] is empty\n");
	} else {
		m_bus = atoi(bus.c_str());
	}

	if (!config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_ADDRESS, address)) {
		ERR("[ADDRESS] is empty\n");
	} else {
		m_address = strtol(address.c_str(), NULL, 16);
	}

	DBG("MISC type=%d %s-%s-%s", m_upm_sensor_type, m_model_id.c_str(), bus.c_str(), address.c_str());

	switch (m_upm_sensor_type) {
		case UPM_BMPX8X:
			DBG("BMP(%d, 0x%x)", m_bus, m_address);
			m_sensor = (upm::BMPX8X *) new upm::BMPX8X(m_bus, m_address);
			m_method = UPM_METHOD;
			m_data_count = 4;
			break;
		case UPM_MPL3115A2:
			DBG("MPL3115A2");
			m_sensor = (upm::MPL3115A2 *) new upm::MPL3115A2(m_bus, m_address);
			m_method = UPM_METHOD;
			m_data_count = 4;
			break;
		case UPM_MPU9150:
			DBG("MPU9150");
			m_sensor = (upm::MPU9150 *) new upm::MPU9150(m_bus, m_address);
			m_method = UPM_METHOD;
			m_data_count = 4;
			break;
		default:
			ERR("Unsupport sensor %d use RAW IO", m_upm_sensor_type);
			m_method = RAW_METHOD;
			m_data_count = 0;
			break;
	}

	if (!config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_VENDOR, m_vendor)) {
		ERR("[VENDOR] is empty\n");
	}

	if (!config.get(SENSOR_TYPE_MISC, m_model_id, ELEMENT_NAME, m_chip_name)) {
		ERR("[NAME] is empty\n");
	}

	INFO("m_vendor = %s", m_vendor.c_str());
	INFO("m_chip_name = %s", m_chip_name.c_str());
	INFO("m_raw_data_unit = %f", m_raw_data_unit);
	return;
}

misc_sensor_hal::~misc_sensor_hal()
{
	ERR("%s", __FUNCTION__);

	if (NULL != m_sensor) {
		switch (m_upm_sensor_type) {
			case UPM_BMPX8X:
				delete (upm::BMPX8X *)m_sensor;
				break;
			UPM_MPL3115A2:
				delete (upm::MPL3115A2 *)m_sensor;
				break;
			UPM_MPU9150:
				delete (upm::MPU9150 *)m_sensor;
				break;
			default:
				break;
		}
	}

	INFO("sensor_hal is destroyed!\n");
}

string misc_sensor_hal::get_model_id(void)
{
	return m_model_id;
}

sensor_type_id_t misc_sensor_hal::get_type(void)
{
	return MISC_SENSOR;
}

bool misc_sensor_hal::enable(void)
{
	AUTOLOCK(m_mutex);

	m_fired_time = 0;
	INFO(" sensor real starting");
	return true;
}

bool misc_sensor_hal::disable(void)
{
	AUTOLOCK(m_mutex);

	INFO(" sensor real stopping");
	return true;
}

bool misc_sensor_hal::set_interval(unsigned long val)
{
	return false;
}

bool misc_sensor_hal::update_value(bool wait)
{
	char readbuf[16];
	float data_raw[16];
	int data_count, i;
	bool get_data = false;
	int read_input_cnt = 0;
	const int INPUT_MAX_BEFORE_SYN = 10;
	unsigned long long fired_time = 0;
	bool syn = false;
	struct timeval sv;

	DBG("%s method=%d ", __FUNCTION__, m_method);

	data_count = 0;
	if (NULL != m_sensor) {
			switch (m_upm_sensor_type) {
				case UPM_BMPX8X:
				{
					upm::BMPX8X *upm_sensor = (upm::BMPX8X*) m_sensor;
					get_data = true;
					data_count = 0;
					data_raw[data_count++] = upm_sensor->getPressure();
					data_raw[data_count++] = upm_sensor->getTemperature();
					data_raw[data_count++] = upm_sensor->getAltitude();
					data_raw[data_count++] = upm_sensor->getSealevelPressure();
					gettimeofday(&sv, NULL);
					fired_time = MICROSECONDS(sv);
					for (i = 0; i < data_count; i++) {
				 		DBG("data_raw=%f", data_raw[i]);
					}
					break;
				}
				case UPM_MPL3115A2:
				{
					upm::MPL3115A2 *upm_sensor = (upm::MPL3115A2*) m_sensor;
					get_data = true;
					data_count = 0;
					data_raw[data_count++] = upm_sensor->getPressure();
					data_raw[data_count++] = upm_sensor->getTemperature();
					data_raw[data_count++] = upm_sensor->getAltitude();
					data_raw[data_count++] = upm_sensor->getSealevelPressure();
					gettimeofday(&sv, NULL);
					fired_time = MICROSECONDS(sv);
					break;
				}
				case UPM_MPU9150:
				{
					upm::MPU9150 *upm_sensor = (upm::MPU9150*) m_sensor;
					upm::Vector3D mpu9150_data;
					get_data = true;
					upm_sensor->getData();
					upm_sensor->getAcceleromter(&mpu9150_data);
					data_count = 0;
					data_raw[data_count++] = mpu9150_data.axisX;
					data_raw[data_count++] = mpu9150_data.axisY;
					data_raw[data_count++] = mpu9150_data.axisZ;
					gettimeofday(&sv, NULL);
					fired_time = MICROSECONDS(sv);
					break;
				}
				default:
					ERR("Unsupported sensor %d", m_upm_sensor_type);
					break;
			}
	} else {
			// TODO
	}

	AUTOLOCK(m_value_mutex);

	if (get_data) {
		m_data_count = data_count;
		for (i = 0; i < data_count; i++) {
		 m_data[i] = data_raw[i];
		}
		m_fired_time = fired_time;
	}
	return true;
}

bool misc_sensor_hal::is_data_ready(bool wait)
{
	bool ret;
	DBG("%s %d", __func__, wait);
	ret = update_value(wait);
	return ret;
}

int misc_sensor_hal::get_sensor_data(sensor_data_t &data)
{
	int i;

	DBG("%s m_set_data=%p", __func__, m_set_data);

	AUTOLOCK(m_value_mutex);

	if (m_set_data) {
		data.timestamp = m_set_data->timestamp;
		data.value_count = m_set_data->value_count;
		memcpy(data.values, m_set_data->values,
		sizeof(m_set_data->values[0]) * m_set_data->value_count);
		return 1;
	}

	data.accuracy = SENSOR_ACCURACY_GOOD;
	data.timestamp = m_fired_time ;
	data.value_count = m_data_count;

	for (i = 0; i < m_data_count; i++) {
		data.values[i] = (float) m_data[i];
	}
	return 0;
}

bool misc_sensor_hal::free_set_data()
{
	AUTOLOCK(m_value_mutex);
	DBG("%s m_set_data=%p", __func__, m_set_data);
	if (m_set_data)
		free(m_set_data);

	m_set_data = NULL;

	return true;
}

bool misc_sensor_hal::get_properties(sensor_properties_s &properties)
{
	properties.name = m_chip_name;
	properties.vendor = m_vendor;
	properties.min_range = -1;
	properties.max_range = -1;
	properties.min_interval = 10;
	properties.resolution = 1.0;
	properties.fifo_count = 0;
	properties.max_batch_count = 0;

	return true;
}

extern "C" sensor_module* create(string &name)
{
	misc_sensor_hal *sensor;

	try {
		sensor = new(std::nothrow) misc_sensor_hal(name);
	} catch (int err) {
		ERR("Failed to create module, err: %d, cause: %s", err, strerror(err));
		return NULL;
	}

	sensor_module *module = new(std::nothrow) sensor_module;
	retvm_if(!module || !sensor, NULL, "Failed to allocate memory");

	module->sensors.push_back(sensor);
	return module;
}
