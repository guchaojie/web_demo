/*
 * temperature_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef _MISC_SENSOR_HAL_H_
#define _MISC_SENSOR_HAL_H_

#include <sensor_hal.h>
#include <string>
#include <upm/bmpx8x.h>
#include <upm/mpl3115a2.h>
#include <upm/mpu9150.h>

typedef enum {
	UPM_UNKNOWN = -1,
	UPM_BMPX8X = 0,
	UPM_MPL3115A2 = 1,
	UPM_MPU9150 = 2,
} upm_sensor_type_t;

struct misc_sensor_dev {
	char	sensor_name[32];
	upm_sensor_type_t sensor_type;
};

using std::string;

class misc_sensor_hal : public sensor_hal
{
public:
	misc_sensor_hal(string &name);
	virtual ~misc_sensor_hal();
	string get_model_id(void);
	sensor_type_id_t get_type(void);
	bool enable(void);
	bool disable(void);
	bool set_interval(unsigned long val);
	bool is_data_ready(bool wait);
	virtual int get_sensor_data(sensor_data_t &data);
	bool free_set_data();
	bool get_properties(sensor_properties_s &properties);
private:
	float m_data[16];
	int m_data_count;

	int m_method;
	unsigned long m_polling_interval;
	unsigned long long m_fired_time;

	string m_model_id;
	string m_vendor;
	string m_chip_name;
	string m_interface;

	float m_raw_data_unit;

	string m_data_node;
	string m_enable_node;
	string m_interval_node;

	upm_sensor_type_t m_upm_sensor_type;
	void * m_sensor;

	cmutex m_value_mutex;

	bool update_value(bool wait);
};
#endif /*_MISC_SENSOR_HAL_CLASS_H_*/
