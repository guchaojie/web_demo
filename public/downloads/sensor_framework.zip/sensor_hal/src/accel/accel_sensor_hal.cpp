/*
 * accel_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <linux/input.h>
#include <csensor_config.h>
#include <accel_sensor_hal.h>
#include <sys/poll.h>

using std::ifstream;

#define GRAVITY 9.80665
#define G_TO_MG 1000
#define RAW_DATA_TO_G_UNIT(X) (((float)(X))/((float)G_TO_MG))
#define RAW_DATA_TO_METRE_PER_SECOND_SQUARED_UNIT(X) (GRAVITY * (RAW_DATA_TO_G_UNIT(X)))

#define MIN_RANGE(RES) (-((1 << (RES))/2))
#define MAX_RANGE(RES) (((1 << (RES))/2)-1)

accel_sensor_hal::accel_sensor_hal(string &name)
: m_x(-1)
, m_y(-1)
, m_z(-1)
, m_node_handle(-1)
, m_polling_interval(POLL_1HZ_MS)
, m_fired_time(0)
{
	csensor_config &config = csensor_config::get_instance();

	node_info_query query;
	node_info info;

	m_model_id = name;
	query.sensor_type = SENSOR_TYPE_ACCEL;
	query.key = m_model_id; //"accelerometer_sensor";
	query.iio_enable_node_name = "accel_enable";

	if (get_node_info(query, info)) {
		show_node_info(info);

		m_method = info.method;
		m_data_node = info.data_node_path;
		m_base_dir = info.base_dir;
		m_enable_node = info.enable_node_path;
		m_interval_node = info.interval_node_path;
		m_buffer_enable_node = info.buffer_enable_node_path;
		m_buffer_length_node = info.buffer_length_node_path;
	} else {
		m_method = -1;
		ERR("Failed to get node info, Physical sensor is not exist!!");
	}

	if (!config.get(SENSOR_TYPE_ACCEL, m_model_id, ELEMENT_VENDOR, m_vendor)) {
		ERR("[VENDOR] is empty\n");
	}

	INFO("m_vendor = %s", m_vendor.c_str());

	if (!config.get(SENSOR_TYPE_ACCEL, m_model_id, ELEMENT_NAME, m_chip_name)) {
		m_chip_name = m_model_id; /* add m_chip_name to make sensor find sensor_hal */
		ERR("[NAME] is empty\n");
	}

	INFO("m_chip_name = %s\n",m_chip_name.c_str());

	long resolution;

	if (!config.get(SENSOR_TYPE_ACCEL, m_model_id, ELEMENT_RESOLUTION, resolution)) {
		ERR("[RESOLUTION] is empty\n");
	}

	m_resolution = (int)resolution;

	INFO("m_resolution = %d\n",m_resolution);

	double raw_data_unit;

	if (!config.get(SENSOR_TYPE_ACCEL, m_model_id, ELEMENT_RAW_DATA_UNIT, raw_data_unit)) {
		ERR("[RAW_DATA_UNIT] is empty\n");
	}

	m_raw_data_unit = (float)(raw_data_unit);
	INFO("m_raw_data_unit = %f\n", m_raw_data_unit);

	if ((m_node_handle = open(m_data_node.c_str(), O_RDWR)) < 0) {
		ERR("accel handle open fail for accel processor, error:%s\n", strerror(errno));
	}

	if (m_method == INPUT_EVENT_METHOD) {
		int clockId = CLOCK_MONOTONIC;
		if (ioctl(m_node_handle, EVIOCSCLOCKID, &clockId) != 0)
			ERR("Fail to set monotonic timestamp for %s", m_data_node.c_str());

		update_value = [=](bool wait) {
			return this->update_value_input_event(wait);
		};
	} else if (m_method == IIO_METHOD) {
		get_accel_nodes();

		update_value = [=](bool wait) {
			return this->update_value_iio(wait);
		};
	}

	INFO("accel_sensor is created!\n");
}

accel_sensor_hal::~accel_sensor_hal()
{
	close(m_node_handle);
	m_node_handle = -1;

	INFO("accel_sensor is destroyed!\n");
}

string accel_sensor_hal::get_model_id(void)
{
	return m_model_id;
}

sensor_type_id_t accel_sensor_hal::get_type(void)
{
	return ACCELEROMETER_SENSOR;
}

bool accel_sensor_hal::get_accel_nodes(void)
{
	m_en_node.resize(4);
	m_en_node[0] = m_base_dir + string("scan_elements/") + string("in_accel_x_en");
	m_en_node[1] = m_base_dir + string("scan_elements/") + string("in_accel_y_en");
	m_en_node[2] = m_base_dir + string("scan_elements/") + string("in_accel_z_en");
	m_en_node[3] = m_base_dir + string("scan_elements/") + string("in_timestamp_en");

	m_index_node.resize(4);
	m_index_node[0] = m_base_dir + string("scan_elements/") + string("in_accel_x_index");
	m_index_node[1] = m_base_dir + string("scan_elements/") + string("in_accel_y_index");
	m_index_node[2] = m_base_dir + string("scan_elements/") + string("in_accel_z_index");
	m_index_node[3] = m_base_dir + string("scan_elements/") + string("in_timestamp_index");

	m_type_node.resize(4);
	m_type_node[0] = m_base_dir + string("scan_elements/") + string("in_accel_x_type");
	m_type_node[1] = m_base_dir + string("scan_elements/") + string("in_accel_y_type");
	m_type_node[2] = m_base_dir + string("scan_elements/") + string("in_accel_z_type");
	m_type_node[3] = m_base_dir + string("scan_elements/") + string("in_timestamp_type");

	return true;
}

bool accel_sensor_hal::enable(void)
{
	AUTOLOCK(m_mutex);

	set_node_value(m_buffer_length_node, 480);

	set_node_value(m_buffer_enable_node, 0);

	for (vector<string>::iterator iter = m_en_node.begin(); iter != m_en_node.end(); ++iter) {
		set_node_value(*iter, 1);
	}

	set_node_value(m_buffer_enable_node, 1);

	set_enable_node(m_enable_node, true);
	set_interval(m_polling_interval);

	m_fired_time = 0;
	INFO("Accel sensor real starting");
	return true;
}

bool accel_sensor_hal::disable(void)
{
	AUTOLOCK(m_mutex);

	set_node_value(m_buffer_length_node, 0);

	set_node_value(m_buffer_enable_node, 0);

	for (vector<string>::iterator iter = m_en_node.begin(); iter != m_en_node.end(); ++iter) {
		set_node_value(*iter, 0);
	}

	set_enable_node(m_enable_node, false);

	INFO("Accel sensor real stopping");
	return true;
}

bool accel_sensor_hal::set_interval(unsigned long val)
{
	unsigned long long polling_interval_ns;

	AUTOLOCK(m_mutex);

	polling_interval_ns = ((unsigned long long)(val) * 1000llu * 1000llu);

	if (!set_node_value(m_interval_node, polling_interval_ns)) {
		ERR("Failed to set polling resource: %s\n", m_interval_node.c_str());
		return false;
	}

	INFO("Interval is changed from %dms to %dms]", m_polling_interval, val);
	m_polling_interval = val;
	return true;
}


bool accel_sensor_hal::update_value_input_event(bool wait)
{
	int accel_raw[3] = {0,};
	bool x,y,z;
	int read_input_cnt = 0;
	const int INPUT_MAX_BEFORE_SYN = 10;
	unsigned long long fired_time = 0;
	bool syn = false;

	x = y = z = false;

	struct input_event accel_input;
	DBG("accel event detection!");

	while ((syn == false) && (read_input_cnt < INPUT_MAX_BEFORE_SYN)) {
		int len = read(m_node_handle, &accel_input, sizeof(accel_input));
		if (len != sizeof(accel_input)) {
			ERR("accel_file read fail, read_len = %d\n",len);
			return false;
		}

		++read_input_cnt;

		if (accel_input.type == EV_REL) {
			switch (accel_input.code) {
			case REL_X:
				accel_raw[0] = (int)accel_input.value;
				x = true;
				break;
			case REL_Y:
				accel_raw[1] = (int)accel_input.value;
				y = true;
				break;
			case REL_Z:
				accel_raw[2] = (int)accel_input.value;
				z = true;
				break;
			default:
				ERR("accel_input event[type = %d, code = %d] is unknown.", accel_input.type, accel_input.code);
				return false;
				break;
			}
		} else if (accel_input.type == EV_SYN) {
			syn = true;
			fired_time = sensor_hal::get_timestamp(&accel_input.time);
		} else {
			ERR("accel_input event[type = %d, code = %d] is unknown.", accel_input.type, accel_input.code);
			return false;
		}
	}

	if (syn == false) {
		ERR("EV_SYN didn't come until %d inputs had come", read_input_cnt);
		return false;
	}

	AUTOLOCK(m_value_mutex);

	if (x)
		m_x =  accel_raw[0];
	if (y)
		m_y =  accel_raw[1];
	if (z)
		m_z =  accel_raw[2];

	m_fired_time = fired_time;

	DBG("m_x = %d, m_y = %d, m_z = %d, time = %lluus", m_x, m_y, m_z, m_fired_time);

	return true;
}


bool accel_sensor_hal::update_value_iio(bool wait)
{
	unsigned long long timestamp = 0;
	const int READ_LEN = 128;
	char data[READ_LEN] = {0,};

	struct pollfd pfd;

	pfd.fd = m_node_handle;
	pfd.events = POLLIN | POLLERR;
	pfd.revents = 0;

	DBG("Start poll ...");

	int ret = poll(&pfd, 1, -1);

	if (ret == -1) {
		ERR("poll error:%s m_node_handle:d", strerror(errno), m_node_handle);
		return false;
	} else if (!ret) {
		ERR("poll timeout m_node_handle:%d", m_node_handle);
		return false;
	}

	if (pfd.revents & POLLERR) {
		ERR("poll exception occurred! m_node_handle:%d", m_node_handle);
		return false;
	}

	if (!(pfd.revents & POLLIN)) {
		ERR("poll nothing to read! m_node_handle:%d, pfd.revents = %d", m_node_handle, pfd.revents);
		return false;
	}

	int len = read(m_node_handle, data, sizeof(data));

	if (len != sizeof(data)) {
		WARN("Failed to read data, m_node_handle:%d read_len:%d", m_node_handle, len);
		//return false;
	}

	AUTOLOCK(m_value_mutex);

	short *short_data = (short *)(data);
	m_x = *(short_data);
	m_y = *((short *)(data + 2));
	m_z = *((short *)(data + 4));

	timestamp = *((long long*)(data + 6));

	INFO("m_x = %d, m_y = %d, m_z = %d, time = %llu us delta=%llu", m_x, m_y, m_z, timestamp, (timestamp - m_fired_time));

	m_fired_time = timestamp;

	return true;

}

bool accel_sensor_hal::is_data_ready(bool wait)
{
	bool ret;
	ret = update_value(wait);
	return ret;
}

int accel_sensor_hal::get_sensor_data(sensor_data_t &data)
{
	AUTOLOCK(m_value_mutex);
	if (m_set_data) {
		data.timestamp = m_set_data->timestamp;
		data.value_count = m_set_data->value_count;
		memcpy(data.values, m_set_data->values,
		sizeof(m_set_data->values[0]) * m_set_data->value_count);
		return 1;
	}

	data.accuracy = SENSOR_ACCURACY_GOOD;
	data.timestamp = m_fired_time;
	data.value_count = 3;
	data.values[0] = m_x;
	data.values[1] = m_y;
	data.values[2] = m_z;

	return 0;
}

bool accel_sensor_hal::free_set_data()
{
	AUTOLOCK(m_value_mutex);
	DBG("%s m_set_data=%p", __func__, m_set_data);
	if (m_set_data)
		free(m_set_data);

	m_set_data = NULL;

	return true;
}

bool accel_sensor_hal::get_properties(sensor_properties_s &properties)
{
	properties.name = m_chip_name;
	properties.vendor = m_vendor;
	properties.min_range = MIN_RANGE(m_resolution)* RAW_DATA_TO_METRE_PER_SECOND_SQUARED_UNIT(m_raw_data_unit);
	properties.max_range = MAX_RANGE(m_resolution)* RAW_DATA_TO_METRE_PER_SECOND_SQUARED_UNIT(m_raw_data_unit);
	properties.min_interval = 1;
	properties.resolution = RAW_DATA_TO_METRE_PER_SECOND_SQUARED_UNIT(m_raw_data_unit);
	properties.fifo_count = 0;
	properties.max_batch_count = 0;
	return true;
}

extern "C" sensor_module* create(string &name)
{
	accel_sensor_hal *sensor;

	try {
		sensor = new(std::nothrow) accel_sensor_hal(name);
	} catch (int err) {
		ERR("Failed to create module, err: %d, cause: %s", err, strerror(err));
		return NULL;
	}

	sensor_module *module = new(std::nothrow) sensor_module;
	retvm_if(!module || !sensor, NULL, "Failed to allocate memory");

	module->sensors.push_back(sensor);
	return module;
}
