/*
 * gyro_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef _GYRO_SENSOR_HAL_H_
#define _GYRO_SENSOR_HAL_H_

#include <sensor_hal.h>
#include <string>
#include <vector>
#include <functional>

using std::string;
using std::vector;

class gyro_sensor_hal : public sensor_hal
{
public:
	gyro_sensor_hal(string &name);
	virtual ~gyro_sensor_hal();
	string get_model_id(void);
	sensor_type_id_t get_type(void);
	bool enable(void);
	bool disable(void);
	bool set_interval(unsigned long ms_interval);
	bool is_data_ready(bool wait);
	virtual int get_sensor_data(sensor_data_t &data);
	bool free_set_data();
	virtual bool get_properties(sensor_properties_s &properties);

private:
	int m_x;
	int m_y;
	int m_z;
	int m_node_handle;
	unsigned long m_polling_interval;
	unsigned long long m_fired_time;

	string m_model_id;
	string m_vendor;
	string m_chip_name;

	float m_min_range;
	float m_max_range;
	int m_resolution;
	float m_raw_data_unit;

	int m_method;
	string m_data_node;
	string m_base_dir;
	string m_enable_node;
	string m_interval_node;
	string m_trigger_node;
	int m_trigger_type;
	string m_buffer_enable_node;
	string m_buffer_length_node;
	vector<string> m_en_node;
	vector<string> m_index_node;
	vector<string> m_type_node;

	bool m_sensorhub_controlled;

	std::function<bool (bool)> update_value;

	cmutex m_value_mutex;

	bool update_value_input_event(bool wait);
	bool update_value_iio(bool wait);

	bool get_gyro_iio_nodes(void);
};
#endif /*_GYRO_SENSOR_HAL_CLASS_H_*/
