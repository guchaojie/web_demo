/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <command_worker.h>
#include <sensor_plugin_loader.h>
#include <sensor_info.h>
#include <sensor_accel.h>
#include <thread>
#include <string>
#include <utility>
#include <cynara_checker.h>
#include <set>

using std::string;
using std::make_pair;
using std::set;

command_worker::cmd_handler_t command_worker::m_cmd_handlers[];
sensor_raw_data_map command_worker::m_sensor_raw_data_map;
cpacket command_worker::m_sensor_list;

set<unsigned int> priority_list;

command_worker::command_worker(const csocket& socket)
: m_client_id(CLIENT_ID_INVALID)
, m_socket(socket)
, m_module(NULL)
{
	static bool init = false;

	if (!init) {
		init_cmd_handlers();
		make_sensor_raw_data_map();

		init = true;
	}

	m_worker.set_context(this);
	m_worker.set_working(working);
	m_worker.set_stopped(stopped);
}

command_worker::~command_worker()
{
	m_socket.close();
}


bool command_worker::start(void)
{
	return m_worker.start();
}

void command_worker::init_cmd_handlers(void)
{
	m_cmd_handlers[CMD_GET_ID]				= &command_worker::cmd_get_id;
	m_cmd_handlers[CMD_GET_SENSOR_LIST]		= &command_worker::cmd_get_sensor_list;
	m_cmd_handlers[CMD_REGISTER_SENSOR]		= &command_worker::cmd_register_sensor;
	m_cmd_handlers[CMD_UNREGISTER_SENSOR]		= &command_worker::cmd_unregister_sensor;
	m_cmd_handlers[CMD_HELLO]				= &command_worker::cmd_hello;
	m_cmd_handlers[CMD_BYEBYE]				= &command_worker::cmd_byebye;
	m_cmd_handlers[CMD_START]				= &command_worker::cmd_start;
	m_cmd_handlers[CMD_STOP]				= &command_worker::cmd_stop;
	m_cmd_handlers[CMD_REG]					= &command_worker::cmd_register_event;
	m_cmd_handlers[CMD_UNREG]				= &command_worker::cmd_unregister_event;
	m_cmd_handlers[CMD_SET_OPTION]			= &command_worker::cmd_set_option;
	m_cmd_handlers[CMD_SET_INTERVAL]		= &command_worker::cmd_set_interval;
	m_cmd_handlers[CMD_UNSET_INTERVAL]		= &command_worker::cmd_unset_interval;
	m_cmd_handlers[CMD_SET_COMMAND]			= &command_worker::cmd_set_command;
	m_cmd_handlers[CMD_GET_DATA]			= &command_worker::cmd_get_data;
	m_cmd_handlers[CMD_GET_RAW_DATA]		= &command_worker::cmd_get_raw_data;
	m_cmd_handlers[CMD_SET_DATA]			= &command_worker::cmd_set_data;
	m_cmd_handlers[CMD_SET_READ_METHOD]		= &command_worker::cmd_set_read_method;
}

void command_worker::get_sensor_list(int privilege, cpacket &sensor_list)
{
	vector<raw_data_t *> sensor_raw_vec;
	size_t total_raw_data_size = 0;

	if (privilege) {
		auto range = m_sensor_raw_data_map.equal_range(privilege);

		sensor_raw_data_map::iterator it_raw_data;

		for (it_raw_data = range.first; it_raw_data != range.second; ++it_raw_data) {
			total_raw_data_size += it_raw_data->second.size();
			sensor_raw_vec.push_back(&(it_raw_data->second));
		}
	}

	int sensor_cnt;

	sensor_cnt = sensor_raw_vec.size();

	sensor_list.set_payload_size(sizeof(cmd_get_sensor_list_done_t) + (sizeof(size_t) * sensor_cnt) + total_raw_data_size);
	sensor_list.set_cmd(CMD_GET_SENSOR_LIST);

	cmd_get_sensor_list_done_t *cmd_get_sensor_list_done;

	cmd_get_sensor_list_done = (cmd_get_sensor_list_done_t*)sensor_list.data();
	cmd_get_sensor_list_done->sensor_cnt = sensor_cnt;
	size_t* size_field = (size_t *) cmd_get_sensor_list_done->data;


	for (int i = 0; i < sensor_cnt; ++i)
		size_field[i] = sensor_raw_vec[i]->size();

	char* raw_data_field = cmd_get_sensor_list_done->data + (sizeof(size_t) * sensor_cnt);

	int idx = 0;
	for (int i = 0; i < sensor_cnt; ++i) {
		copy(sensor_raw_vec[i]->begin(), sensor_raw_vec[i]->end(), raw_data_field + idx);
		idx += sensor_raw_vec[i]->size();
	}

}

void command_worker::make_sensor_raw_data_map(void)
{
	vector<sensor_base *> sensors;
	sensor_info info;
	int privilege;

	sensors = sensor_plugin_loader::get_instance().get_sensors(ALL_SENSOR);

	auto it_sensor = sensors.begin();

	m_sensor_raw_data_map.clear();

	while (it_sensor != sensors.end()) {
		(*it_sensor)->get_sensor_info(info);
		privilege = (*it_sensor)->get_privilege();

		sensor_raw_data_map::iterator it_sensor_raw_data;
		it_sensor_raw_data = m_sensor_raw_data_map.insert(std::make_pair(privilege, raw_data_t()));

		info.get_raw_data(it_sensor_raw_data->second);
		info.clear();
		++it_sensor;
	}
}

bool command_worker::working(void *ctx)
{
	bool ret;
	command_worker *inst = (command_worker *)ctx;

	packet_header header;
	char *payload;

	DBG("+%s", __FUNCTION__);

	if (inst->m_socket.recv(&header, sizeof(header)) <= 0) {
		string info;
		inst->get_info(info);
		DBG("%s failed to receive header", info.c_str());
		return false;
	}

	DBG("%s cmd=0x%x size=%d", __FUNCTION__, header.cmd, header.size);

	if (header.size > 0) {
		payload = new(std::nothrow) char[header.size];
		retvm_if(!payload, false, "Failed to allocate memory");

		if (inst->m_socket.recv(payload, header.size) <= 0) {
			string info;
			inst->get_info(info);
			DBG("%s failed to receive data of packet", info.c_str());
			delete[] payload;
			return false;
		}
	} else {
		payload = NULL;
	}

	ret = inst->dispatch_command(header.cmd, payload);

	if (payload)
		delete[] payload;

	return ret;
}


bool command_worker::stopped(void *ctx)
{
	string info;
	event_type_vector event_vec;
	command_worker *inst = (command_worker *)ctx;

	inst->get_info(info);
	INFO("%s is stopped", info.c_str());

	if ((inst->m_module) && (inst->m_client_id != CLIENT_ID_INVALID)) {

		get_client_info_manager().get_registered_events(inst->m_client_id, inst->m_module->get_id(), event_vec);

		auto it_event = event_vec.begin();

		while (it_event != event_vec.end()) {
			WARN("Does not unregister event[0x%x] before connection broken for [%s]!!", *it_event, inst->m_module->get_name());
			if (!inst->m_module->delete_client(*it_event))
				ERR("Unregistering event[0x%x] failed", *it_event);

			++it_event;
		}

		if (get_client_info_manager().is_started(inst->m_client_id, inst->m_module->get_id())) {
			WARN("Does not receive cmd_stop before connection broken for [%s]!!", inst->m_module->get_name());
			inst->m_module->delete_interval(inst->m_client_id, false);
			inst->m_module->stop();
		}

		if (inst->m_module->get_id()) {
			if (get_client_info_manager().has_sensor_record(inst->m_client_id, inst->m_module->get_id())) {
				INFO("Removing sensor[0x%x] record for client_id[%d]", inst->m_module->get_id(), inst->m_client_id);
				get_client_info_manager().remove_sensor_record(inst->m_client_id, inst->m_module->get_id());
			}
		}
	}

	delete inst;
	return true;
}

bool command_worker::dispatch_command(int cmd, void* payload)
{
	int ret = false;

	DBG("+%s cmd=0x%x(0x10=GET_DAT 0x12=SET_DAT)", __FUNCTION__, cmd);

	if (!(cmd > 0 && cmd < CMD_CNT)) {
		ERR("Unknown command: %d", cmd);
	} else {
		cmd_handler_t cmd_handler;
		cmd_handler = command_worker::m_cmd_handlers[cmd];
		if (cmd_handler)
			ret = (this->*cmd_handler)(payload);
	}

	return ret;
}

bool command_worker::send_cmd_done(long value)
{
	cpacket* ret_packet;
	cmd_done_t *cmd_done;

	ret_packet = new(std::nothrow) cpacket(sizeof(cmd_done_t));
	retvm_if(!ret_packet, false, "Failed to allocate memory");

	ret_packet->set_cmd(CMD_DONE);

	cmd_done = (cmd_done_t*)ret_packet->data();
	cmd_done->value = value;

	if (m_socket.send(ret_packet->packet(), ret_packet->size()) <= 0) {
		ERR("Failed to send a cmd_done to client_id [%d] with value [%ld]", m_client_id, value);
		delete ret_packet;
		return false;
	}

	delete ret_packet;
	return true;

}


bool command_worker::send_cmd_get_id_done(int client_id)
{
	cpacket* ret_packet;
	cmd_get_id_done_t *cmd_get_id_done;

	ret_packet = new(std::nothrow) cpacket(sizeof(cmd_get_id_done_t));
	retvm_if(!ret_packet, false, "Failed to allocate memory");

	ret_packet->set_cmd(CMD_GET_ID);

	cmd_get_id_done = (cmd_get_id_done_t*)ret_packet->data();
	cmd_get_id_done->client_id = client_id;

	if (m_socket.send(ret_packet->packet(), ret_packet->size()) <= 0) {
		ERR("Failed to send a cmd_get_id_done with client_id [%d]", client_id);
		delete ret_packet;
		return false;
	}

	delete ret_packet;
	return true;
}

bool command_worker::send_cmd_register_sensor_done(long value, unsigned int id)
{
	cpacket* ret_packet;
	cmd_register_sensor_done_t *cmd_register_sensor_done;

	ret_packet = new(std::nothrow) cpacket(sizeof(cmd_register_sensor_done_t));
	retvm_if(!ret_packet, false, "Failed to allocate memory");

	ret_packet->set_cmd(CMD_REGISTER_SENSOR);

	cmd_register_sensor_done = (cmd_register_sensor_done_t*)ret_packet->data();
	cmd_register_sensor_done->id = id;
	cmd_register_sensor_done->state = value;

	if (m_socket.send(ret_packet->packet(), ret_packet->size()) <= 0) {
		ERR("Failed to send a cmd_register_sensor_done");
		delete ret_packet;
		return false;
	}

	delete ret_packet;
	return true;
}

bool command_worker::send_cmd_get_data_done(int state, sensor_data_t *data)
{

	cpacket* ret_packet;
	cmd_get_data_done_t *cmd_get_data_done;

	ret_packet = new(std::nothrow) cpacket(sizeof(cmd_get_data_done_t));
	retvm_if(!ret_packet, false, "Failed to allocate memory");

	DBG("%s", __FUNCTION__);

	ret_packet->set_cmd(CMD_GET_DATA);

	cmd_get_data_done = (cmd_get_data_done_t*)ret_packet->data();
	cmd_get_data_done->state = state;

	memcpy(&cmd_get_data_done->base_data , data, sizeof(sensor_data_t));

	if (m_socket.send(ret_packet->packet(), ret_packet->size()) <= 0) {
		ERR("Failed to send a cmd_get_data_done");
		delete ret_packet;
		return false;
	}

	delete ret_packet;
	return true;
}

bool command_worker::send_cmd_get_raw_data_done(unsigned char *data, unsigned int data_cnt)
{
	cpacket ret_packet;
	cmd_get_raw_data_done_t *cmd_get_raw_data_done;

	ret_packet.set_payload_size(sizeof(cmd_get_raw_data_done_t) +
					(sizeof(unsigned char) * data_cnt));
	ret_packet.set_cmd(CMD_GET_RAW_DATA);

	cmd_get_raw_data_done = (cmd_get_raw_data_done_t *)ret_packet.data();
	cmd_get_raw_data_done->data_cnt = data_cnt;

	memcpy(cmd_get_raw_data_done->data, data, data_cnt);

	if (m_socket.send(ret_packet.packet(), ret_packet.size()) <= 0) {
		ERR("Failed to send a cmd_get_raw_data_done");
		return false;
	}

	return true;
}

bool command_worker::send_cmd_get_sensor_list_done(void)
{
	cpacket sensor_list;
	int privilege = SENSOR_PRIVILEGE_NONE;

	if (check_privilege(SENSOR_PRIVILEGE_PUBLIC))
		privilege = SENSOR_PRIVILEGE_PUBLIC;
	else if (check_privilege(SENSOR_PRIVILEGE_INTERNAL))
		privilege = SENSOR_PRIVILEGE_INTERNAL;

	get_sensor_list(privilege, sensor_list);

	if (m_socket.send(sensor_list.packet(), sensor_list.size()) <= 0) {
		ERR("Failed to send a cmd_get_sensor_list_done");
		return false;
	}

	return true;
}

bool command_worker::cmd_get_id(void *payload)
{
	cmd_get_id_t *cmd;
	int client_id;

	DBG("CMD_GET_ID Handler invoked\n");
	cmd = (cmd_get_id_t*)payload;

	client_id = get_client_info_manager().create_client_record();
	get_client_info_manager().set_client_info(client_id, cmd->pid);

	INFO("New client id [%d] created", client_id);

	if (!send_cmd_get_id_done(client_id))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_register_sensor(void *payload)
{
	unsigned int len;
	sensor_id_t sensor_id;
	hal_id_t hal_id = 0;
	long ret_value = OP_SUCCESS;
	char name[SENSOR_NAME_SIZE] = {0,};
	string sensor_name;

	int sensor_type_id;
	char type[SENSOR_TYPE_NAME_SIZE] = {0,};
	string sensor_type;

	string hal, sensor;

	strcpy(name, (char *)payload);
	len = strlen(name);
	sensor_name = name;

	sensor_type_id = *(int *)((char *)payload + len + 1);
	strcpy(type, (char *)payload + len + 1 + sizeof(int));
	sensor_type = type;

	if (!sensor_plugin_loader::get_instance().get_plugins(sensor_type, hal, sensor)) {
		ERR("no plugin for type %s", sensor_type.c_str());
		ret_value = OP_ERROR;
		goto out;
	}

	if (!sensor_plugin_loader::get_instance().insert_hal_module(sensor_name, hal, hal_id)) {
		ret_value = OP_ERROR;
		goto out;
	}
	if (!sensor_plugin_loader::get_instance().insert_sensor_module(sensor_name, sensor, hal_id, sensor_id)) {
		ret_value = OP_ERROR;
		goto out;
	}

	make_sensor_raw_data_map();

out:
	if (!send_cmd_register_sensor_done(ret_value, sensor_id))
		ERR("Failed to send register_sensor_done to a client");

	return true;
}

bool command_worker::cmd_unregister_sensor(void *payload)
{
	sensor_id_t id;
	long ret_value = OP_ERROR;

	id = *(sensor_id_t *)payload;

	if(sensor_plugin_loader::get_instance().del_sensor(id))
		ret_value = OP_SUCCESS;

	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	make_sensor_raw_data_map();

	return true;
}

bool command_worker::cmd_get_sensor_list(void *payload)
{
	DBG("CMD_GET_SENSOR_LIST Handler invoked\n");

	if (!send_cmd_get_sensor_list_done())
		ERR("Failed to send cmd_get_sensor_list_done to a client");

	return true;
}

bool command_worker::cmd_hello(void *payload)
{
	cmd_hello_t *cmd;
	long ret_value = OP_ERROR;

	DBG("CMD_HELLO Handler invoked\n");
	cmd = (cmd_hello_t*)payload;

	m_client_id = cmd->client_id;

	m_module = (sensor_base *)sensor_plugin_loader::get_instance().get_sensor(cmd->sensor);

	if (!m_module) {
		ERR("Sensor type[%d] is not supported", cmd->sensor);
		if (!get_client_info_manager().has_sensor_record(m_client_id))
			get_client_info_manager().remove_client_record(m_client_id);

		ret_value = OP_ERROR;
		goto out;
	}

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to connect sensor[0x%x] for client [%d]", m_module->get_id(), m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	DBG("Hello sensor [0x%x], client id [%d]", m_module->get_id(), m_client_id);
	get_client_info_manager().create_sensor_record(m_client_id, m_module->get_id());
	INFO("New sensor record created for sensor [0x%x], sensor name [%s] on client id [%d]\n", m_module->get_id(), m_module->get_name(), m_client_id);
	ret_value = OP_SUCCESS;
out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_byebye(void *payload)
{
	long ret_value = OP_ERROR;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to stop sensor[0x%x] for client [%d]", m_module? m_module->get_id() : -1, m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	DBG("CMD_BYEBYE for client [%d], sensor [0x%x]", m_client_id, m_module->get_id());

	if (!get_client_info_manager().remove_sensor_record(m_client_id, m_module->get_id())) {
		ERR("Error removing sensor_record for client [%d]", m_client_id);
		ret_value = OP_ERROR;
		goto out;
	}

	m_client_id = CLIENT_ID_INVALID;
	ret_value = OP_SUCCESS;

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	if (ret_value == OP_SUCCESS)
		return false;

	return true;
}

bool command_worker::cmd_start(void *payload)
{
	long ret_value = OP_ERROR;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to start sensor[0x%x] for client [%d]", m_module? m_module->get_id() : -1, m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	DBG("START Sensor [0x%x], called from client [%d]", m_module->get_id(), m_client_id);

	if (m_module->start()) {
		get_client_info_manager().set_start(m_client_id, m_module->get_id(), true);
/*
 *	Rotation could be changed even LCD is off by pop sync rotation
 *	and a client listening rotation event with always-on option.
 *	To reflect the last rotation state, request it to event dispatcher.
 */
		get_event_dispathcher().request_last_event(m_client_id, m_module->get_id());
		ret_value = OP_SUCCESS;
	} else {
		ERR("Failed to start sensor [0x%x] for client [%d]", m_module->get_id(), m_client_id);
		ret_value = OP_ERROR;
	}

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_stop(void *payload)
{
	long ret_value = OP_ERROR;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to stop sensor[0x%x] for client [%d]", m_module? m_module->get_id() : -1, m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	DBG("STOP Sensor [0x%x], called from client [%d]", m_module->get_id(), m_client_id);

	if (m_module->stop()) {
		get_client_info_manager().set_start(m_client_id, m_module->get_id(), false);
		ret_value = OP_SUCCESS;
	} else {
		ERR("Failed to stop sensor [0x%x] for client [%d]", m_module->get_id(), m_client_id);
		ret_value = OP_ERROR;
	}

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_register_event(void *payload)
{
	cmd_reg_t *cmd;
	long ret_value = OP_ERROR;

	cmd = (cmd_reg_t*)payload;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to register event [0x%x] for client [%d] to client info manager",
			cmd->event_type, m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	if (!get_client_info_manager().register_event(m_client_id, m_module? m_module->get_id() : -1, cmd->event_type)) {
		INFO("Failed to register event [0x%x] for client [%d] to client info manager",
			cmd->event_type, m_client_id);
		ret_value = OP_ERROR;
		goto out;
	}

	insert_priority_list(cmd->event_type);
	m_module->add_client(cmd->event_type);

	ret_value = OP_SUCCESS;
	DBG("Registering Event [0x%x] is done for client [%d]", cmd->event_type, m_client_id);

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_unregister_event(void *payload)
{
	cmd_unreg_t *cmd;
	long ret_value = OP_ERROR;

	cmd = (cmd_unreg_t*)payload;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to unregister event [0x%x] for client [%d] to client info manager",
			cmd->event_type, m_client_id);
		ret_value = OP_SENSOR_DENY;
		goto out;
	}

	if (!get_client_info_manager().unregister_event(m_client_id, m_module->get_id(), cmd->event_type)) {
		ERR("Failed to unregister event [0x%x] for client [%d] from client info manager",
			cmd->event_type, m_client_id);
		ret_value = OP_ERROR;
		goto out;
	}

	if (!m_module->delete_client(cmd->event_type)) {
		ERR("Failed to unregister event [0x%x] for client [%d]",
			cmd->event_type, m_client_id);
		ret_value = OP_ERROR;
		goto out;
	}

	ret_value = OP_SUCCESS;
	DBG("Unregistering Event [0x%x] is done for client [%d]",
		cmd->event_type, m_client_id);

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_set_interval(void *payload)
{
	cmd_set_interval_t *cmd;
	long ret_value = OP_ERROR;

	cmd = (cmd_set_interval_t*)payload;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to register interval for client [%d], for sensor [0x%x] with interval [%d] to client info manager",
			m_client_id, m_module? m_module->get_id() : -1, cmd->interval);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	if (!get_client_info_manager().set_interval(m_client_id, m_module->get_id(), cmd->interval)) {
		ERR("Failed to register interval for client [%d], for sensor [0x%x] with interval [%d] to client info manager",
			m_client_id, m_module->get_id(), cmd->interval);
		ret_value = OP_ERROR;
		goto out;
	}

	if (!m_module->add_interval(m_client_id, cmd->interval, false)) {
		ERR("Failed to set interval for client [%d], for sensor [0x%x] with interval [%d]",
			m_client_id, m_module->get_id(), cmd->interval);
		ret_value = OP_ERROR;
		goto out;
	}

	ret_value = OP_SUCCESS;

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_unset_interval(void *payload)
{
	long ret_value = OP_ERROR;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to unregister interval for client [%d], for sensor [0x%x] to client info manager",
			m_client_id, m_module? m_module->get_id() : -1);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	if (!get_client_info_manager().set_interval(m_client_id, m_module->get_id(), 0)) {
		ERR("Failed to unregister interval for client [%d], for sensor [0x%x] to client info manager",
			m_client_id, m_module->get_id());
		ret_value = OP_ERROR;
		goto out;
	}

	if (!m_module->delete_interval(m_client_id, false)) {
		ERR("Failed to delete interval for client [%d]", m_client_id);
		ret_value = OP_ERROR;
		goto out;
	}

	ret_value = OP_SUCCESS;

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_set_option(void *payload)
{
	cmd_set_option_t *cmd;
	long ret_value = OP_ERROR;

	cmd = (cmd_set_option_t*)payload;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to set interval for client [%d],for sensor [0x%x] with option [%d] to client info manager",			m_client_id, m_module? m_module->get_id() : -1, cmd->option);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	if (!get_client_info_manager().set_option(m_client_id, m_module->get_id(), cmd->option)) {
		ERR("Failed to set option for client [%d], for sensor [0x%x] with option [%d] to client info manager",
			m_client_id, m_module->get_id(), cmd->option);
		ret_value = OP_ERROR;
		goto out;
	}

	ret_value = OP_SUCCESS;
out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_set_command(void *payload)
{
	cmd_set_command_t *cmd;
	long ret_value = OP_ERROR;

	DBG("CMD_SET_COMMAND  Handler invoked\n");

	cmd = (cmd_set_command_t*)payload;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to set command for client [%d], for sensor [0x%x] with cmd [%d]",
			m_client_id, m_module? m_module->get_id() : -1, cmd->cmd);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	ret_value = m_module->set_command(cmd->cmd, cmd->value);

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_get_data(void *payload)
{
	const int GET_DATA_MIN_INTERVAL = 10;
	cmd_get_data_t *cmd;
	int state = OP_ERROR;
	bool adjusted = false;

	sensor_data_t data;

	DBG("%s Handler invoked\n", __FUNCTION__);

	cmd = (cmd_get_data_t*)payload;

	if (!check_privilege(m_module->get_privilege())) {
		ERR("Permission denied to get data for client [%d], for sensor [0x%x]",
			m_client_id, m_module? m_module->get_id() : -1);
		state = OP_SENSOR_DENY;
		goto out;
	}

	state = m_module->get_sensor_data(cmd->type, data);
	DBG("%s %s-%s state=%d data.timestamp=%llu",
		__func__, m_module->get_name(), m_module->get_sensor_type(), state, data.timestamp);

	// In case of not getting sensor data, wait short time and retry again
	// 1. changing interval to be less than 10ms
	// 2. In case of first time, wait for INIT_WAIT_TIME
	// 3. at another time, wait for WAIT_TIME
	// 4. retrying to get data
	// 5. repeat 2 ~ 4 operations RETRY_CNT times
	// 6. reverting back to original interval
	if (!state && !data.timestamp) {
		const int RETRY_CNT	= 3;
		const unsigned long long INIT_WAIT_TIME = 20000; //20ms
		const unsigned long WAIT_TIME = 100000;	//100ms
		int retry = 0;

		unsigned int interval = m_module->get_interval(m_client_id, false);

		if (interval > GET_DATA_MIN_INTERVAL) {
			m_module->add_interval(m_client_id, GET_DATA_MIN_INTERVAL, false);
			adjusted = true;
		}

		while (!state && !data.timestamp && (retry++ < RETRY_CNT)) {
			INFO("%d-%llu %s-%s Wait sensor[0x%x] data updated for client [%d] #%d",
				state, data.timestamp, m_module->get_name(), m_module->get_sensor_type(), m_module->get_id(), m_client_id, retry);
			usleep((retry == 1) ? INIT_WAIT_TIME : WAIT_TIME);
			state = m_module->get_sensor_data(cmd->type, data);
			DBG("%s %s-%s state=%d data.timestamp=%llu",
		__func__, m_module->get_name(), m_module->get_sensor_type(), state, data.timestamp);
		}

		if (adjusted)
			m_module->add_interval(m_client_id, interval, false);
	}

	if (!data.timestamp)
		state = OP_ERROR;

	if (state) {
		ERR("Failed to get data for client [%d], for sensor [0x%x]",
			m_client_id, m_module->get_id());
	}

out:
	send_cmd_get_data_done(state, &data);

	return true;
}

bool command_worker::cmd_get_raw_data(void *payload)
{
	const int GET_DATA_MIN_INTERVAL = 10;
	cmd_get_raw_data_t *cmd;
	int state = OP_ERROR;
	bool adjusted = false;
	unsigned char *data;
	unsigned int data_cnt;

	cmd = (cmd_get_raw_data_t*)payload;

	DBG("%s Handler invoked\n", __FUNCTION__);

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to set read method for client [%d], for sensor [0x%x]",
			m_client_id, m_module? m_module->get_id() : -1);
		state = OP_WRITE_DENY;
		goto out;
	}

	data = (unsigned char *)malloc((cmd->size)*sizeof(unsigned char));
	data_cnt = cmd->size;

	state = m_module->get_sensor_raw_data(data, data_cnt);
	if (state) {
		const int RETRY_CNT	= 3;
		const unsigned long long INIT_WAIT_TIME = 20000; //20ms
		const unsigned long WAIT_TIME = 100000;	//100ms
		int retry = 0;

		unsigned int interval = m_module->get_interval(m_client_id, false);

		if (interval > GET_DATA_MIN_INTERVAL) {
			m_module->add_interval(m_client_id, GET_DATA_MIN_INTERVAL, false);
			adjusted = true;
		}

		while (state && (retry++ < RETRY_CNT)) {
			INFO("Wait sensor[0x%x] data updated for client [%d] #%d", m_module->get_id(), m_client_id, retry);
			usleep((retry == 1) ? INIT_WAIT_TIME : WAIT_TIME);
			state = m_module->get_sensor_raw_data(data, data_cnt);
		}

		if (adjusted)
			m_module->add_interval(m_client_id, interval, false);
	}

	if (state) {
		ERR("Failed to get data for client [%d], for sensor [0x%x]",
			m_client_id, m_module->get_id());
		state = OP_ERROR;
	}

out:
	send_cmd_get_raw_data_done(data, data_cnt);

	free(data);

	return true;
}

bool command_worker::cmd_set_data(void *payload)
{
	cmd_set_data_t *cmd;
	int ret_value = OP_ERROR;

	DBG("+%s invoked\n", __FUNCTION__);

	cmd = (cmd_set_data_t*)payload;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to set read method for client [%d], for sensor [0x%x]",
			m_client_id, m_module? m_module->get_id() : -1);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	ret_value = m_module->set_sensor_data(cmd->set_data);

	DBG("%s %s COUNT=%d", __func__, m_module->get_name(), (cmd->set_data).value_count);

	if (ret_value) {
		ERR("Failed to set data for client [%d], for sensor [0x%x] state=%d",
			m_client_id, m_module->get_id(), ret_value);
	}

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

bool command_worker::cmd_set_read_method(void *payload)
{
	cmd_set_read_method_t *cmd;
	int ret_value = OP_ERROR;

	cmd = (cmd_set_read_method_t*)payload;

	if (!check_privilege(SENSOR_PRIVILEGE_INTERNAL)) {
		ERR("Permission denied to set read method for client [%d], for sensor [0x%x]",
			m_client_id, m_module? m_module->get_id() : -1);
		ret_value = OP_WRITE_DENY;
		goto out;
	}

	ret_value = m_module->set_read_method(cmd->hw_info);

out:
	if (!send_cmd_done(ret_value))
		ERR("Failed to send cmd_done to a client");

	return true;
}

void command_worker::get_info(string &info)
{
	const char *client_info = NULL;
	const char *sensor_info = NULL;

	if (m_client_id != CLIENT_ID_INVALID)
		client_info = get_client_info_manager().get_client_info(m_client_id);

	if (m_module)
		sensor_info = m_module->get_name();

	info = string("Command worker for ") + (client_info ? client_info : "Unknown") + "'s "
		+ (sensor_info ? sensor_info : "Unknown");
}

int command_worker::check_privilege(sensor_privilege_t privilege)
{
	return cynara_checker::get_instance().check_privilege(m_socket.get_socket_fd(), privilege);
}

cclient_info_manager& command_worker::get_client_info_manager(void)
{
	return cclient_info_manager::get_instance();
}

csensor_event_dispatcher& command_worker::get_event_dispathcher(void)
{
	return csensor_event_dispatcher::get_instance();
}

void insert_priority_list(unsigned int event_type)
{

}
