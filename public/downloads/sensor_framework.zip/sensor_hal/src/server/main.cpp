/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <stdlib.h>
#include <signal.h>
#include <common.h>
#include <server.h>
#include <dbus_util.h>
#include <csensor_config.h>
#include <sensor_plugin_loader.h>
#include "i2c-dev.h"
#include <mraa.h>

#define MODE_AUTO	0
#define MODE_QUICK	1
#define MODE_READ	2
#define MODE_FUNC	3

int execute_command(char *command)
{
	int ret;
	DBG("%s [%s]", __FUNCTION__, command);
	ret = system(command);
	DBG("%s [%s] ret=%d", __FUNCTION__, command, ret);
	return ret;
}

int auto_load_driver(unsigned char i2cbus, unsigned char address)
{
	char command[256];
	int i, ret;
	bool found = false;
	string drv_name;
	char addrbuf[16];

	snprintf(addrbuf, sizeof(addrbuf), "0x%02x", address);

	csensor_config &config = csensor_config::get_instance();

	found = config.find_device(string(addrbuf), drv_name);

	if (found) {
		sprintf(command,"modprobe %s-i2c", drv_name.c_str());
		ret = execute_command(command);

		if (0 != ret) {
			sprintf(command,"modprobe %s", drv_name.c_str());
			ret = execute_command(command);
		}

		if (0 == ret) {
			sprintf(command,"echo %s 0x%02x > /sys/bus/i2c/devices/i2c-%d/new_device",
				drv_name.c_str(), address, i2cbus);
			ret = execute_command(command);
		} else {
			ERR("driver load fail!");
		}
	} else {
		WARN("Device driver for 0x%02x@%d not found! Unsupported...", address, i2cbus);
		ret = -1;
	}
	return ret;
}

int open_i2c_dev(int i2cbus, char *filename, size_t size, int quiet)
{
	int file;

	snprintf(filename, size, "/dev/i2c/%d", i2cbus);
	filename[size - 1] = '\0';
	file = open(filename, O_RDWR);

	if (file < 0 && (errno == ENOENT || errno == ENOTDIR)) {
		sprintf(filename, "/dev/i2c-%d", i2cbus);
		file = open(filename, O_RDWR);
	}

	if (file < 0 && !quiet) {
		if (errno == ENOENT) {
			fprintf(stderr, "Error: Could not open file "
				"`/dev/i2c-%d' or `/dev/i2c/%d': %s\n",
				i2cbus, i2cbus, strerror(ENOENT));
		} else {
			fprintf(stderr, "Error: Could not open file "
				"`%s': %s\n", filename, strerror(errno));
			if (errno == EACCES)
				fprintf(stderr, "Run as root?\n");
		}
	}

	return file;
}


// scan i2c bus, if found device, try to load the related device drivers
int scan_i2c_bus(int i2cbus, int file, int mode, unsigned long funcs,
			int first, int last)
{
	int i, j, ret;
	int cmd, res;
	char *sensor_name;

	printf("BUS %d\n", i2cbus);
	printf("     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f\n");

	for (i = 0; i < 128; i += 16) {
		printf("%02x: ", i);
		for(j = 0; j < 16; j++) {
			fflush(stdout);

			/* Select detection command for this address */
			switch (mode) {
			default:
				cmd = mode;
				break;
			case MODE_AUTO:
				if ((i+j >= 0x30 && i+j <= 0x37)
				 || (i+j >= 0x50 && i+j <= 0x5F))
				 	cmd = MODE_READ;
				else
					cmd = MODE_QUICK;
				break;
			}

			/* Skip unwanted addresses */
			if (i+j < first || i+j > last
			 || (cmd == MODE_READ &&
			     !(funcs & I2C_FUNC_SMBUS_READ_BYTE))
			 || (cmd == MODE_QUICK &&
			     !(funcs & I2C_FUNC_SMBUS_QUICK))) {
				printf("   ");
				continue;
			}

			/* Set slave address */
			if (ioctl(file, I2C_SLAVE, i+j) < 0) {
				if (errno == EBUSY) {
					printf("UU ");
					DBG("0x%02x is using kernel driver!", i+j);
					continue;
				} else {
					fprintf(stderr, "Error: Could not set "
						"address to 0x%02x: %s\n", i+j,
						strerror(errno));
					return -1;
				}
			}

			/* Probe this address */
			switch (cmd) {
			default: /* MODE_QUICK */
				/* This is known to corrupt the Atmel AT24RF08
				   EEPROM */
				res = i2c_smbus_write_quick(file,
				      I2C_SMBUS_WRITE);
				break;
			case MODE_READ:
				/* This is known to lock SMBus on various
				   write-only chips (mainly clock chips) */
				res = i2c_smbus_read_byte(file);
				break;
			}

			if (res < 0) {
				printf("-- ");
			}
			else {
				printf("%02x ", i+j);
				DBG("find a device@0x%02x on bus %d loading driver...", i+j, i2cbus);
				// load the related device driver
				ret = auto_load_driver(i2cbus, i + j);
				if (ret != 0) {
					WARN("Load drvier fail! Use direct IO");
					// TODO
				}
			}
		}
		printf("\n");
	}

	return 0;
}

int detect_sensors()
{
	unsigned long funcs;
	int file, i2cbus, res, count, i;
	char i2c_devname[20];
	char* board_name = mraa_get_platform_name();

	if (NULL == board_name) {
		ERR("Unsupported Platform!");
		return -1;
	}

	DBG("%s board_name=[%s]", __FUNCTION__, board_name);

	if (0 == strcmp("Intel DE3815", board_name)) {
		DBG("%s on DE3815...", __FUNCTION__);
		i2cbus = 8;
		count = 2;

	} else if (0 == strcmp("MinnowBoard MAX", board_name)) {
		DBG("%s on Minnowmax...", __FUNCTION__);
		i2cbus = 8;
		count = 1;
	} else {
		DBG("Unsupport board!");
		return -1;
	}

	execute_command("modprobe iio-trig-sysfs");

	for (i = i2cbus; i < i2cbus + count; i++) {
		file = open_i2c_dev(i, i2c_devname, sizeof(i2c_devname), 0);
		if (file < 0) {
			ERR("Open I2C %d error!", i);
			continue;
		}

		if (ioctl(file, I2C_FUNCS, &funcs) < 0) {
			fprintf(stderr, "Error: Could not get the adapter "
				"functionality matrix: %s\n", strerror(errno));
			close(file);
			continue;
		}

		res = scan_i2c_bus(i, file, MODE_READ, funcs, 0, 0xff);

		close(file);
	}
	return 0;
}


int sensor_detect()
{

}

static void sig_term_handler(int signo, siginfo_t *info, void *data)
{
	char proc_name[NAME_MAX];

	get_proc_name(info->si_pid, proc_name);

	ERR("Received SIGTERM(%d) from %s(%d)\n", signo, proc_name, info->si_pid);
	exit(EXIT_SUCCESS);
}

static void signal_init(void)
{
	struct sigaction sig_act;
	memset(&sig_act, 0, sizeof(struct sigaction));

	sig_act.sa_handler = SIG_IGN;
	sigaction(SIGCHLD, &sig_act, NULL);
	sigaction(SIGPIPE, &sig_act, NULL);

	sig_act.sa_handler = NULL;
	sig_act.sa_sigaction = sig_term_handler;
	sig_act.sa_flags = SA_SIGINFO;
	sigaction(SIGTERM, &sig_act, NULL);
}

int main(int argc, char *argv[])
{
	INFO("\nINFO Sensord started\n");
	DBG("DBG %s %s:%s", __FILE__, __DATE__, __TIME__);
	detect_sensors();

	signal_init();

	sensor_plugin_loader::get_instance().load_plugins();

	server::get_instance().run();

	server::get_instance().stop();

	sensor_plugin_loader::get_instance().destroy();

	INFO("Sensord terminated");
	return 0;
}
