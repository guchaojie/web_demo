/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef _CYNARA_CHECKER_H_
#define _CYNARA_CHECKER_H_

#include <string>
#include <vector>
#include <memory>
#include <sensor_common.h>
#include <cynara-client.h>
#include <cynara-creds-socket.h>

class cynara_checker {
private:
	cynara_checker();
	~cynara_checker();
	cynara_checker(cynara_checker const &) {};
	cynara_checker & operator = (cynara_checker const &);

	void sensor_cynara_init();
	void sensor_cynara_deinit();

	cynara *m_cynara;
	cynara_configuration *m_conf;
	enum cynara_client_creds m_client_creds_method;
	enum cynara_user_creds m_user_creds_method;
public:
	static cynara_checker & get_instance();

	int check_privilege(int sock_fd, sensor_privilege_t privilege);
};

#endif
