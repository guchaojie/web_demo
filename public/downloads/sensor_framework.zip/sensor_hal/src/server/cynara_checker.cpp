/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <cynara_checker.h>
#include <sf_common.h>
#include <common.h>
#include <sensor_plugin_loader.h>
#include <sensor_base.h>

cynara_checker::cynara_checker()
: m_cynara(NULL)
, m_conf(NULL)
, m_client_creds_method(CLIENT_METHOD_SMACK)
, m_user_creds_method(USER_METHOD_UID)
{
#ifdef CYNARA_ENABLE
	sensor_cynara_init();
#endif
}

cynara_checker::~cynara_checker()
{
	if (m_cynara)
		sensor_cynara_deinit();
}

cynara_checker& cynara_checker::get_instance()
{
	static cynara_checker inst;
	return inst;
}

void cynara_checker::sensor_cynara_init()
{
	int result;
	char err_msg[256] = {0, };

	if (m_cynara != NULL) {
		ERR("Cynara pointer already initialize!");
		return;
	}

	result = cynara_initialize(&m_cynara, m_conf);

	if (result != CYNARA_API_SUCCESS) {
		cynara_strerror(result, err_msg, sizeof(err_msg));
		ERR("Fail to initialize cynara: [%s]", err_msg);
		return;
	}
}

void cynara_checker::sensor_cynara_deinit()
{
	int result;
	char err_msg[256] = {0, };

	result = cynara_finish(m_cynara);

	if (result != CYNARA_API_SUCCESS) {
		cynara_strerror(result, err_msg, sizeof(err_msg));
		ERR("Fail to finish cynara: [%s]", err_msg);
		return;
	}

	m_cynara = NULL;
	m_conf = NULL;
}

int cynara_checker::check_privilege(int sock_fd, sensor_privilege_t privilege)
{
	const char *privilege_list;
	char *client_creds = NULL;
	char *user_creds = NULL;
	char *client_session = "";
	char err_msg[256] = {0, };
	int ret_val;

#ifdef CYNARA_ENABLE
	if (privilege == SENSOR_PRIVILEGE_PUBLIC)
		privilege_list = PUBLIC_PRIVILEGE_LIST;
	else if (privilege == SENSOR_PRIVILEGE_INTERNAL)
		privilege_list = INTERNAL_PRIVILEGE_LIST;
	else {
		ERR("This privilege is not invalid !");
		return false;
	}

	ret_val = cynara_creds_get_default_client_method(&m_client_creds_method);
	if (ret_val != CYNARA_API_SUCCESS) {
		cynara_strerror(ret_val, err_msg, sizeof(err_msg));
		ERR("Fail to get default client method: %s", err_msg);
		return false;
	}

	ret_val = cynara_creds_get_default_user_method(&m_user_creds_method);
	if (ret_val != CYNARA_API_SUCCESS) {
		cynara_strerror(ret_val, err_msg, sizeof(err_msg));
		ERR("Fail to get default user method: %s", err_msg);
		return false;
	}

	ret_val = cynara_creds_socket_get_client(sock_fd, m_client_creds_method, &client_creds);
	if (ret_val != CYNARA_API_SUCCESS) {
		cynara_strerror(ret_val, err_msg, sizeof(err_msg));
		ERR("Fail to get client credential: %s", err_msg);
		return false;
	}

	ret_val = cynara_creds_socket_get_user(sock_fd, m_user_creds_method, &user_creds);
	if (ret_val != CYNARA_API_SUCCESS) {
		cynara_strerror(ret_val, err_msg, sizeof(err_msg));
		ERR("Fail to get user credential: %s", err_msg);
		if (client_creds)
			free(client_creds);
		return false;
	}

	ret_val = cynara_check(m_cynara, client_creds, client_session,
							user_creds, privilege_list);
	if (ret_val != CYNARA_API_ACCESS_ALLOWED) {
#ifdef CYNARA_FAKE
		return true;
#else
		ERR("Fail to access: %s", privilege_list);
		return false;
#endif
	}
#endif
	return true;
}
