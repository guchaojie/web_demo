/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#ifndef _LIGHT_SENSOR_H_
#define _LIGHT_SENSOR_H_

#include <sensor_common.h>

#include <physical_sensor.h>
#include <sensor_hal.h>

class light_sensor : public physical_sensor {
public:
	light_sensor(string &name);
	virtual ~light_sensor();

	bool init(hal_id_t hal_id);
	sensor_type_id_t get_type(void);

	static bool working(void *inst);
	int set_read_method(sf_sensor_hw_t hw_info);

	bool set_interval(unsigned long interval);
	virtual bool get_properties(sensor_properties_s &properties);
	virtual int set_sensor_data(sensor_data_t data);
	virtual int get_sensor_data(unsigned int type, sensor_data_t &data);
	virtual int get_sensor_raw_data(unsigned char *data, unsigned int &size);

private:
	sensor_hal *m_sensor_hal;
	float m_light;
	float m_resolution;

	virtual bool on_start(void);
	virtual bool on_stop(void);
	bool process_event(void);
	void raw_to_base(sensor_data_t &data);
};

#endif
