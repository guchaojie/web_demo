/*
 * sensord
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

#include <common.h>
#include <sf_common.h>
#include <light_sensor.h>
#include <sensor_plugin_loader.h>
#include <csensor_config.h>
#include <algorithm>
#include <csensor_config.h>

using std::bind1st;
using std::mem_fun;

light_sensor::light_sensor(string &name)
: m_sensor_hal(NULL)
, m_resolution(0.0f)
{
	m_name = name;
	m_sensor_type = SENSOR_TYPE_LIGHT;

	register_supported_event(LIGHT_LUX_DATA_EVENT);

	physical_sensor::set_poller(light_sensor::working, this);
}

light_sensor::~light_sensor()
{
	INFO("light_sensor is destroyed!");
}

bool light_sensor::init(hal_id_t hal_id)
{
	m_to_hal_id = hal_id;
	DBG("m_to_hal_id = 0x%x", m_to_hal_id);
	m_sensor_hal = sensor_plugin_loader::get_instance().get_sensor_hal(LIGHT_SENSOR, hal_id);

	if (!m_sensor_hal) {
		ERR("cannot load sensor_hal[%s]", sensor_base::get_name());
		return false;
	}

	sensor_properties_s properties;

	if (!m_sensor_hal->get_properties(properties)) {
		ERR("sensor->get_properties() is failed!\n");
		return false;
	}

	m_resolution = properties.resolution;

	string model_id = m_sensor_hal->get_model_id();

	csensor_config &config = csensor_config::get_instance();

	INFO("%s is created!", sensor_base::get_name());

	return true;
}

sensor_type_id_t light_sensor::get_type(void)
{
	return LIGHT_SENSOR;
}

bool light_sensor::working(void *inst)
{
	light_sensor *sensor = (light_sensor*)inst;
	return sensor->process_event();
}

bool light_sensor::process_event(void)
{
	sensor_event_t event;

	DBG("%s", __FUNCTION__);

	if (!m_sensor_hal->is_data_ready(true))
		return true;

	m_sensor_hal->get_sensor_data(event.data);

	AUTOLOCK(m_client_info_mutex);

	if (get_client_cnt(LIGHT_LUX_DATA_EVENT)) {
		event.sensor_id = get_id();
		event.event_type = LIGHT_LUX_DATA_EVENT;
		raw_to_base(event.data);
		push(event);
	}

	return true;
}

bool light_sensor::on_start(void)
{
	if (!m_sensor_hal->enable()) {
		ERR("m_sensor_hal start fail\n");
		return false;
	}

	return start_poll();
}

bool light_sensor::on_stop(void)
{
	if (!m_sensor_hal->disable()) {
		ERR("m_sensor_hal stop fail\n");
		return false;
	}

	return stop_poll();
}

bool light_sensor::get_properties(sensor_properties_s &properties)
{
	return m_sensor_hal->get_properties(properties);
}

int light_sensor::get_sensor_data(unsigned int type, sensor_data_t &data)
{
	int ret;

	DBG("%s type=%d", __FUNCTION__, type);

	ret = m_sensor_hal->get_sensor_data(data);
	DBG("%s ret=%d", __func__, ret);
	if (ret < 0)
		return -1;

	if (ret > 0) {
		DBG("%s free_", __func__);
		m_sensor_hal->free_set_data();
		return 0;
	}

	raw_to_base(data);
	return 0;
}

int light_sensor::set_sensor_data(sensor_data_t data)
{
	int ret;

	ret = m_sensor_hal->set_sensor_data(data);
	if (ret < 0)
		return -1;

	return 0;
}

int light_sensor::get_sensor_raw_data(unsigned char *data, unsigned int &size)
{
	int ret;

	DBG("+%s size=%d", __FUNCTION__, size);

	ret = m_sensor_hal->get_sensor_raw_data(data, size);
	if (ret < 0)
		return -1;

	return 0;
}

int light_sensor::set_read_method(sf_sensor_hw_t hw_info)
{
	DBG("%s 0x%x-0x%x-0x%x", __func__, hw_info.bus_num, hw_info.sensor_address, hw_info.sensor_register);
	AUTOLOCK(m_mutex);

	if (m_sensor_hal->set_read_method(hw_info) < 0) {
		ERR("Failed to set read method");
		return -1;
	}

	return 0;
}

bool light_sensor::set_interval(unsigned long interval)
{
	AUTOLOCK(m_mutex);

	INFO("Polling interval is set to %dms", interval);

	return m_sensor_hal->set_interval(interval);
}

void light_sensor::raw_to_base(sensor_data_t &data)
{
	data.value_count = 1;
	DBG("%f-%f", data.values[0], m_resolution);
}

extern "C" sensor_module* create(string &name)
{
	light_sensor *sensor;

	try {
		sensor = new(std::nothrow) light_sensor(name);
	} catch (int err) {
		ERR("Failed to create module, err: %d, cause: %s", err, strerror(err));
		return NULL;
	}

	sensor_module *module = new(std::nothrow) sensor_module;
	retvm_if(!module || !sensor, NULL, "Failed to allocate memory");

	module->sensors.push_back(sensor);
	return module;
}
