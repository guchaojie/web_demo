/*
 * light_sensor_hal
 *
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <fcntl.h>
#include <sys/stat.h>
#include <dirent.h>
#include <linux/input.h>
#include <csensor_config.h>
#include <light_sensor_hal.h>
#include <sys/ioctl.h>
#include <fstream>

using std::ifstream;

light_sensor_hal::light_sensor_hal(string &name)
: m_light(0)
, m_polling_interval(POLL_1HZ_MS)
, m_fired_time(0)
, m_node_handle(-1)
{
	csensor_config &config = csensor_config::get_instance();

	node_info_query query;
	node_info info;

	m_model_id = name;
	DBG("%s found m_model_id=[%s] name=[%s]", __FUNCTION__, m_model_id.c_str(), name.c_str());

	query.sensor_type = "light";
	query.key = m_model_id;
	query.iio_enable_node_name = "light_enable";

	bool error = get_node_info(query, info);

	if (error) {
		show_node_info(info);
		m_method = info.method;
		m_data_node = info.data_node_path;
		m_enable_node = info.enable_node_path;
		m_interval_node = info.interval_node_path;
	} else {
		ERR("Failed to get node info");
	}

	if (name == string("tsl2563")) {
		m_data_node = info.base_dir + "in_illuminance0_input";
		DBG("Using data_node %s!", m_data_node.c_str());
	}

	if (!config.get(SENSOR_TYPE_LIGHT, m_model_id, ELEMENT_VENDOR, m_vendor)) {
		ERR("[VENDOR] is empty\n");
	}

	INFO("m_vendor = %s", m_vendor.c_str());

	if (!config.get(SENSOR_TYPE_LIGHT, m_model_id, ELEMENT_NAME, m_chip_name)) {
		ERR("[NAME] is empty\n");
	}

	INFO("m_chip_name = %s", m_chip_name.c_str());

	INFO("m_raw_data_unit = %f\n", m_raw_data_unit);

	if ((m_node_handle = open(m_data_node.c_str(),O_RDWR)) < 0) {
		WARN("Failed to RW open (%s) %s", m_data_node.c_str(), strerror(errno));
		if ((m_node_handle = open(m_data_node.c_str(),O_RDONLY)) < 0) {
			ERR("Failed to RD open (%s) %s", m_data_node.c_str(), strerror(errno));
		}
	}

	INFO("light_sensor_hal is created!\n");
}

light_sensor_hal::~light_sensor_hal()
{
	close(m_node_handle);
	m_node_handle = -1;

	INFO("light_sensor_hal is destroyed!\n");
}

string light_sensor_hal::get_model_id(void)
{
	return m_model_id;
}

sensor_type_id_t light_sensor_hal::get_type(void)
{
	return LIGHT_SENSOR;
}

bool light_sensor_hal::enable(void)
{
	AUTOLOCK(m_mutex);

	set_enable_node(m_enable_node, true);

	set_interval(m_polling_interval);

	m_fired_time = 0;

	update_value(false);

	INFO("light sensor real starting");
	return true;
}

bool light_sensor_hal::disable(void)
{
	AUTOLOCK(m_mutex);

	set_enable_node(m_enable_node, false);

	INFO("Light sensor real stopping");
	return true;
}

bool light_sensor_hal::set_interval(unsigned long val)
{
	unsigned long long polling_interval_ns;

	AUTOLOCK(m_mutex);

	polling_interval_ns = ((unsigned long long)(val) * 1000llu * 1000llu);

	INFO("Interval is changed from %d ms to %d ms", m_polling_interval, val);
	m_polling_interval = val;
	return true;
}

bool light_sensor_hal::update_value(bool wait)
{
	char readbuf[16];
	int light_raw[3] = {0,};
	bool light = false;
	int read_input_cnt = 0;
	const int INPUT_MAX_BEFORE_SYN = 10;
	unsigned long long fired_time = 0;
	bool syn = false;
	struct timeval sv;

	struct input_event light_event;

	DBG("%s method=%d ", __FUNCTION__, m_method);

	if (lseek(m_node_handle, 0, SEEK_SET) < 0) {
			ERR("lseek error! [%s]\n", strerror(errno));
			// TODO error recovery
	}

	memset(readbuf, 0, sizeof(readbuf));
	int len = read(m_node_handle, readbuf, sizeof(readbuf));

	light = true;
	light_raw[0] = strtol(readbuf, NULL, 10);
	DBG("Get data [%s] len=%d %d", readbuf, len, light_raw[0]);

	gettimeofday(&sv, NULL);
	fired_time = MICROSECONDS(sv);

	AUTOLOCK(m_value_mutex);

	if (light)
		m_light = light_raw[0];

	m_fired_time = fired_time;

	DBG("m_light = %f, time = %llu us", m_light, m_fired_time);

	return true;
}

bool light_sensor_hal::is_data_ready(bool wait)
{
	bool ret;

	DBG("%s", __FUNCTION__);

	ret = update_value(wait);
	return ret;
}

int light_sensor_hal::get_sensor_data(sensor_data_t &data)
{
	AUTOLOCK(m_value_mutex);
	DBG("%s m_set_data=%p", __func__, m_set_data);
	if (m_set_data) {
		data.timestamp = m_set_data->timestamp;
		data.value_count = m_set_data->value_count;
		memcpy(data.values, m_set_data->values,
		sizeof(m_set_data->values[0]) * m_set_data->value_count);
		return 1;
	}

	data.accuracy = SENSOR_ACCURACY_GOOD;
	data.timestamp = m_fired_time ;
	data.value_count = 1;
	data.values[0] = m_light;

	DBG("%s %llu", __FUNCTION__, data.timestamp);
	return 0;
}

bool light_sensor_hal::free_set_data()
{
	AUTOLOCK(m_value_mutex);
	DBG("%s m_set_data=%p", __func__, m_set_data);
	if (m_set_data)
		free(m_set_data);

	m_set_data = NULL;

	return true;
}

bool light_sensor_hal::get_properties(sensor_properties_s &properties)
{
	properties.name = m_chip_name;
	properties.vendor = m_vendor;
	properties.min_range = m_min_range;
	properties.max_range = m_max_range;
	properties.min_interval = 1;
	properties.resolution = m_raw_data_unit;
	properties.fifo_count = 0;
	properties.max_batch_count = 0;
	return true;
}

extern "C" sensor_module* create(string &name)
{
	light_sensor_hal *sensor;

	try {
		sensor = new(std::nothrow) light_sensor_hal(name);
	} catch (int err) {
		ERR("Failed to create module, err: %d, cause: %s", err, strerror(err));
		return NULL;
	}

	sensor_module *module = new(std::nothrow) sensor_module;
	retvm_if(!module || !sensor, NULL, "Failed to allocate memory");

	module->sensors.push_back(sensor);
	return module;
}
