#ifndef __SF_SENSOR_TYPE_H__
#define __SF_SENSOR_TYPE_H__

#include <sensor_common.h>

typedef unsigned int sf_sensor_id_t;

struct sf_sensor_s;

#ifdef __cplusplus
extern "C"
{
#endif

/* Sensor Type Interfaces */
int32_t sf_get_sensor_type_count(uint32_t *count);
int32_t sf_get_sensor_type_list(uint32_t count, sf_sensor_type_t *list);
int32_t sf_sensor_type_is_supported(sf_sensor_type_t *type);
int32_t sf_get_type_of_sensor(sf_sensor_id_t sensor_id, sf_sensor_type_t *type);

#ifdef __cplusplus
}
#endif

#endif /* __SF_SENSOR_TYPE_H__ */
