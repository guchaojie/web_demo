#ifndef __SF_ADAPTER__
#define __SF_ADAPTER__

#include <sf_sensor_type.h>
#include <sf_sensor.h>

#include <sensor_common.h>
#include <sensor_info.h>

bool check_type_name(sf_sensor_type_t type);

void sf_sensorid_to_sensorid(const sf_sensor_id_t &sf_id, sensor_id_t& id);
void sensorid_to_sf_sensorid(const sensor_id_t &id, sf_sensor_id_t& sf_id);

void sf_typeid_to_typeid(const sf_sensor_type_id_t &sf_typeid, sensor_type_id_t &tid);
void typeid_to_sf_typeid(const sensor_type_id_t &tid, sf_sensor_type_id_t &sf_typeid);

void sensorinfo_to_sf_sensor(sensor_info info, sf_sensor_t &sf_sensor);

#endif
