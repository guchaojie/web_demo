#ifndef __cplusplus
#define __cplusplus
#endif
#include <string.h>

#include <sf_sensor.h>
#include <sf_error.h>
#include <sf_adapter.h>

#include <sensor_info.h>
#include <sensor_info_manager.h>
#include <csensor_event_listener.h>
#include <client_common.h>
#include <cmutex.h>
#include <command_channel.h>

#ifndef API
#define API __attribute__ ((visibility("default")))
#endif

extern csensor_event_listener &event_listener;
static cmutex lock;

static int g_power_save_state = 0;
static int g_power_save_state_cb_cnt = 0;

static int get_power_save_state (void)
{
	int state = 0;
	int pm_state;

#if 0
	if (pm_state == VCONFKEY_PM_STATE_LCDOFF)
		state |= SENSOR_OPTION_ON_IN_SCREEN_OFF;
#endif
	return state;
}

static void set_power_save_state_cb(void)
{
	if (g_power_save_state_cb_cnt < 0)
		_E("g_power_save_state_cb_cnt(%d) is wrong", g_power_save_state_cb_cnt);

	++g_power_save_state_cb_cnt;

	if (g_power_save_state_cb_cnt == 1) {
		_D("Power save callback is registered");
		g_power_save_state = get_power_save_state();
		_D("power_save_state = [%d]", g_power_save_state);
	}
}

static void unset_power_save_state_cb(void)
{
	--g_power_save_state_cb_cnt;

	if (g_power_save_state_cb_cnt < 0)
		_E("g_power_save_state_cb_cnt(%d) is wrong", g_power_save_state_cb_cnt);

	if (g_power_save_state_cb_cnt == 0) {
		_D("Power save callback is unregistered");
	}
}

static bool get_events_diff(event_type_vector &a_vec, event_type_vector &b_vec, event_type_vector &add_vec, event_type_vector &del_vec)
{
	sort(a_vec.begin(), a_vec.end());
	sort(b_vec.begin(), b_vec.end());

	set_difference(a_vec.begin(), a_vec.end(), b_vec.begin(), b_vec.end(), back_inserter(del_vec));
	set_difference(b_vec.begin(), b_vec.end(), a_vec.begin(), a_vec.end(), back_inserter(add_vec));

	return !(add_vec.empty() && del_vec.empty());
}

static bool change_sensor_rep(sensor_id_t sensor_id, sensor_rep &prev_rep, sensor_rep &cur_rep)
{
	int client_id;
	command_channel *cmd_channel;
	event_type_vector add_event_types, del_event_types;

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s", get_client_name(), get_sensor_name(sensor_id));
		return false;
	}

	client_id = event_listener.get_client_id();
	retvm_if ((client_id < 0), false, "Invalid client id : %d, %s, %s", client_id, get_sensor_name(sensor_id), get_client_name());

	get_events_diff(prev_rep.event_types, cur_rep.event_types, add_event_types, del_event_types);

	if (cur_rep.active) {
		if (prev_rep.option != cur_rep.option) {
			if (!cmd_channel->cmd_set_option(cur_rep.option)) {
				ERR("Sending cmd_set_option(%d, %s, %d) failed for %s", client_id, get_sensor_name(sensor_id), cur_rep.option, get_client_name());
				return false;
			}
		}

		if (prev_rep.interval != cur_rep.interval) {
			unsigned int min_interval;

			if (cur_rep.interval == 0)
				min_interval= POLL_MAX_HZ_MS;
			else
				min_interval = cur_rep.interval;

			if (!cmd_channel->cmd_set_interval(min_interval)) {
				ERR("Sending cmd_set_interval(%d, %s, %d) failed for %s", client_id, get_sensor_name(sensor_id), min_interval, get_client_name());
				return false;
			}
		}

		if (!add_event_types.empty()) {
			if (!cmd_channel->cmd_register_events(add_event_types)) {
				ERR("Sending cmd_register_events(%d, add_event_types) failed for %s", client_id, get_client_name());
	sensor_id_t sensor_id;
				return false;
			}
		}

	}

	if (prev_rep.active && !del_event_types.empty()) {
		if (!cmd_channel->cmd_unregister_events(del_event_types)) {
			ERR("Sending cmd_unregister_events(%d, del_event_types) failed for %s", client_id, get_client_name());
			return false;
		}
	}

	if (prev_rep.active != cur_rep.active) {
		if (cur_rep.active) {
			if (!cmd_channel->cmd_start()) {
				ERR("Sending cmd_start(%d, %s) failed for %s", client_id, get_sensor_name(sensor_id), get_client_name());
				return false;
			}
		} else {
			if (!cmd_channel->cmd_unset_interval()) {
				ERR("Sending cmd_unset_interval(%d, %s) failed for %s", client_id, get_sensor_name(sensor_id), get_client_name());
				return false;
			}

			if (!cmd_channel->cmd_stop()) {
				ERR("Sending cmd_stop(%d, %s) failed for %s", client_id, get_sensor_name(sensor_id), get_client_name());
				return false;
			}
		}
	}

	return true;
}

API int32_t sf_register_sensor(char *name, sf_sensor_type_t type, sf_sensor_id_t *id)
{
	command_channel cmd_channel;

	if (!name)
	    return SF_ERROR_INVALID_PARAM;

	if (!check_type_name(type))
	    return SF_ERROR_INVALID_SENSOR_TYPE;

	AUTOLOCK(lock);

	if (!cmd_channel.create_channel()) {
		ERR("%s failed to create command channel", get_client_name());
		return SF_ERROR_CREATE_CHANNEL_FAILED;
	}

	if (!cmd_channel.cmd_register_sensor(name, type, id))
		return SF_ERROR_CMD_REG_SENSOR_FAILED;

	if (!cmd_channel.cmd_get_sensor_list()) {
		ERR("%s failed to get sensor list after register", get_client_name());
		return SF_ERROR_CMD_GET_SENSOR_FAILED;
	}

	return SF_SUCCESS;
}

API int32_t sf_unregister_sensor(sf_sensor_id_t id)
{
	command_channel cmd_channel;
	int handle;

	if (!sensor_info_manager::get_instance().is_valid(id))
		return SF_ERROR_INVALID_SENSOR_ID;

	if (event_listener.get_handle_id(id, handle)) {
		ERR("sensor: %d is running, cannot be unregisered.", id);
		return SF_ERROR_SENSOR_IS_BUSY;
	}

	AUTOLOCK(lock);

	if (!cmd_channel.create_channel()) {
		ERR("%s failed to create command channel", get_client_name());
		return SF_ERROR_CREATE_CHANNEL_FAILED;
	}

	if (!cmd_channel.cmd_unregister_sensor(id))
		return SF_ERROR_CMD_UNREG_SENSOR_FAILED;

	if (!cmd_channel.cmd_get_sensor_list()) {
		ERR("%s failed to get sensor list after register", get_client_name());
		return SF_ERROR_CMD_GET_SENSOR_FAILED;
	}

	return SF_SUCCESS;
}

/*
 * Get the sensor count of the specific sensor type.
 */

API int32_t sf_get_sensor_count(sf_sensor_type_t type, uint32_t *count)
{
	if (!count)
		return SF_ERROR_INVALID_PARAM;

	if (!sensor_info_manager::get_instance().is_valid(type.sensor_type_id))
		return SF_ERROR_INVALID_SENSOR_TYPE;

	vector<sensor_info *> sensor_infos =
		sensor_info_manager::get_instance().get_infos(type.sensor_type_id);

	*count = sensor_infos.size();

	return SF_SUCCESS;
}

static void fetch_sensor_from_info(sensor_info info, sf_sensor_t* sensor)
{
	sensor->sensor_id = info.get_id();
	strcpy(sensor->sensor_name, info.get_name());
	sensor->sensor_type.sensor_type_id = info.get_type_id();
	strcpy(sensor->sensor_type.sensor_type, info.get_sensor_type());

	return;
}

API int32_t sf_get_sensor_list(sf_sensor_type_t type, int count, sf_sensor_t *list)
{
	if (!sensor_info_manager::get_instance().is_valid(type.sensor_type_id))
		return SF_ERROR_INVALID_SENSOR_TYPE;

	if (list == NULL)
		return SF_ERROR_INVALID_PARAM;

	vector<sensor_info *> sensor_infos =
		sensor_info_manager::get_instance().get_infos(type.sensor_type_id);

	sf_sensor_t *ptr = list;
	for (uint32_t i = 0; i < sensor_infos.size() && i < count; i++) {
		fetch_sensor_from_info(*(sensor_infos[i]), ptr);
		ptr++;
	}

	return SF_SUCCESS;
}

API int32_t sf_get_sensor_by_id(sf_sensor_id_t id, sf_sensor_t *sensor)
{
	if (!sensor_info_manager::get_instance().is_valid(id))
		return SF_ERROR_INVALID_SENSOR_ID;

	if (sensor == NULL)
		return SF_ERROR_INVALID_PARAM;

	const sensor_info *info =
		sensor_info_manager::get_instance().get_info(id);

	fetch_sensor_from_info((*info), sensor);

	return SF_SUCCESS;
}

API int32_t sf_get_default_sensor(sf_sensor_type_t type, sf_sensor_t *sensor)
{
	vector<sensor_info *> sensor_infos;

	if (!sensor_info_manager::get_instance().is_valid(type.sensor_type_id))
		return SF_ERROR_INVALID_SENSOR_TYPE;

	if (sensor == NULL)
		return SF_ERROR_INVALID_PARAM;

	const sensor_info *info =
		sensor_info_manager::get_instance().get_info(type.sensor_type_id);

	fetch_sensor_from_info((*info), sensor);

	return SF_SUCCESS;
}

static bool sf_sensord_start(int handle, int option)
{
	sensor_id_t sensor_id;
	sensor_rep prev_rep, cur_rep;
	bool ret;
	int prev_state, prev_option;

	AUTOLOCK(lock);

	if (!event_listener.get_sensor_id(handle, sensor_id)) {
		ERR("client %s failed to get handle information", get_client_name());
		return false;
	}

	retvm_if ((option < 0) || (option >= SENSOR_OPTION_END), false, "Invalid option value : %d, handle: %d, %s, %s",
		option, handle, get_sensor_name(sensor_id), get_client_name());

	INFO("%s starts %s[%d], with option: %d, power save state: %d", get_client_name(), get_sensor_name(sensor_id),
		handle, option, g_power_save_state);

	if (g_power_save_state && !(g_power_save_state & option)) {
		event_listener.set_sensor_params(handle, SENSOR_STATE_PAUSED, option);
		return true;
	}

	event_listener.get_sensor_rep(sensor_id, prev_rep);
	event_listener.get_sensor_params(handle, prev_state, prev_option);
	event_listener.set_sensor_params(handle, SENSOR_STATE_STARTED, option);
	event_listener.get_sensor_rep(sensor_id, cur_rep);

	ret = change_sensor_rep(sensor_id, prev_rep, cur_rep);

	if (!ret)
		event_listener.set_sensor_params(handle, prev_state, prev_option);

	return ret;
}

static bool sf_sensord_stop(int handle)
{
	sensor_id_t sensor_id;
	int sensor_state;
	bool ret;
	int prev_state, prev_option;

	sensor_rep prev_rep, cur_rep;

	AUTOLOCK(lock);

	if (!event_listener.get_sensor_state(handle, sensor_state)||
		!event_listener.get_sensor_id(handle, sensor_id)) {
		ERR("client %s failed to get handle information", get_client_name());
		return false;
	}

	retvm_if ((sensor_state == SENSOR_STATE_STOPPED), true, "%s already stopped with %s[%d]",
		get_client_name(), get_sensor_name(sensor_id), handle);


	INFO("%s stops sensor %s[%d]", get_client_name(), get_sensor_name(sensor_id), handle);

	event_listener.get_sensor_rep(sensor_id, prev_rep);
	event_listener.get_sensor_params(handle, prev_state, prev_option);
	event_listener.set_sensor_state(handle, SENSOR_STATE_STOPPED);
	event_listener.get_sensor_rep(sensor_id, cur_rep);

	ret = change_sensor_rep(sensor_id, prev_rep, cur_rep);

	if (!ret)
		event_listener.set_sensor_params(handle, prev_state, prev_option);

	return ret;
}

/* Sensor Control Interfaces. */
API int32_t sf_connect_sensor(sf_sensor_id_t sensor_id)
{
	command_channel *cmd_channel = NULL;
	int handle;
	int client_id;
	bool sensor_registered;
	bool first_connection = false;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	sensor_registered = event_listener.is_sensor_registered(sensor_id);

	handle = event_listener.create_handle(sensor_id);
	if (handle == MAX_HANDLE) {
		ERR("Maximum number of handles reached, sensor: %s in client %s", get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_MAX_HANDLE_REACHED;
	}

	if (!sensor_registered) {
		cmd_channel = new(std::nothrow) command_channel();
		if (!cmd_channel) {
			ERR("Fail to allocate memory");
			return SF_ERROR_OUT_OF_MEMORY;
		}

		if (!cmd_channel->create_channel()) {
			ERR("%s failed to create command channel for %s", get_client_name(), get_sensor_name(sensor_id));
			event_listener.delete_handle(handle);
			delete cmd_channel;
			return SF_ERROR_CREATE_CHANNEL_FAILED;
		}

		event_listener.add_command_channel(sensor_id, cmd_channel);
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("%s failed to get command channel for %s", get_client_name(), get_sensor_name(sensor_id));
		event_listener.delete_handle(handle);
		return SF_ERROR_GET_CHANNEL_FAILED;
	}

	if (!event_listener.has_client_id()) {
		first_connection = true;
		if(!cmd_channel->cmd_get_id(client_id)) {
			ERR("Sending cmd_get_id() failed for %s", get_sensor_name(sensor_id));
			event_listener.close_command_channel(sensor_id);
			event_listener.delete_handle(handle);
			return SF_ERROR_CMD_GET_ID_FAILED;
		}

		event_listener.set_client_id(client_id);
		INFO("%s gets client_id [%d]", get_client_name(), client_id);
		event_listener.start_event_listener();
		INFO("%s starts listening events with client_id [%d]", get_client_name(), client_id);
	}

	client_id = event_listener.get_client_id();
	cmd_channel->set_client_id(client_id);

	INFO("%s[%d] connects with %s[%d]", get_client_name(), client_id, get_sensor_name(sensor_id), handle);

	event_listener.set_sensor_params(handle, SENSOR_STATE_STOPPED, SENSOR_OPTION_DEFAULT);

	if (!sensor_registered) {
		if(!cmd_channel->cmd_hello(sensor_id)) {
			ERR("Sending cmd_hello(%s, %d) failed for %s", get_sensor_name(sensor_id), client_id, get_client_name());
			event_listener.close_command_channel(sensor_id);
			event_listener.delete_handle(handle);
			if (first_connection) {
				event_listener.set_client_id(CLIENT_ID_INVALID);
				event_listener.stop_event_listener();
			}
			return SF_ERROR_CMD_HELLO_FAILED;
		}
	}

	set_power_save_state_cb();

	if (!sf_sensord_start(handle, 1))
		return SF_ERROR_CMD_START_FAILED;

	return SF_SUCCESS;
}

API int32_t sf_disconnect_sensor(sf_sensor_id_t sensor_id)
{
	command_channel *cmd_channel;
	int client_id, handle;
	int sensor_state;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s",
					get_client_name(), get_sensor_name(sensor_id));
		return SF_ERROR_GET_CHANNEL_FAILED;
	}


	client_id = event_listener.get_client_id();
	if (client_id < 0) {
		ERR("Invalid client id : %d, handle: %d, %s, %s",
			client_id, handle, get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_GET_CLIENT_ID_FAILED;
	}

	INFO("%s disconnects with %s[%d]", get_client_name(), get_sensor_name(sensor_id), handle);

	if (sensor_state != SENSOR_STATE_STOPPED) {
		WARN("%s[%d] for %s is not stopped before disconnecting.",
			get_sensor_name(sensor_id), handle, get_client_name());
		sf_sensord_stop(handle);
	}

	if (!event_listener.delete_handle(handle))
		return SF_ERROR_DELETE_HANDLE_FAILED;

	if (!event_listener.is_active())
		event_listener.set_client_id(CLIENT_ID_INVALID);

	if (!event_listener.is_sensor_registered(sensor_id)) {
		if(!cmd_channel->cmd_byebye()) {
			ERR("Sending cmd_byebye(%d, %s) failed for %s",
					client_id, get_sensor_name(sensor_id), get_client_name());
			return SF_ERROR_CMD_BYE_FAILED;
		}
		event_listener.close_command_channel(sensor_id);
	}

	if (!event_listener.is_active()) {
		INFO("Stop listening events for client %s with client id [%d]",
						get_client_name(), event_listener.get_client_id());
		event_listener.stop_event_listener();
	}

	unset_power_save_state_cb();

	return SF_SUCCESS;
}


API int32_t sf_get_sensor_status(sf_sensor_id_t sensor_id, sf_sensor_status_t *status)
{
	int handle, sensor_state;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (sensor_state == SENSOR_STATE_STOPPED)
		*status = SF_SENSOR_READY;
	else if (sensor_state = SENSOR_STATE_STARTED)
		*status = SF_SENSOR_RUNNING;

	return SF_SUCCESS;
}

API int32_t sf_get_sensor_name(sf_sensor_id_t id, const char **name)
{
	sensor_info* info;

	if (!sensor_info_manager::get_instance().is_valid(id))
		return SF_ERROR_INVALID_SENSOR_ID;

	if (!name)
		return SF_ERROR_INVALID_PARAM;

	info = sensor_info_manager::get_instance().get_info(id);
	if (!info)
		return SF_ERROR_GET_INFO_FAILED;

	*name = info->get_name();

	return SF_SUCCESS;
}

API int32_t sf_get_sensor_privilege(sf_sensor_id_t id,  const char **privilege)
{
	sensor_info* info;
	sensor_privilege_t sf_privilege;

	if (!sensor_info_manager::get_instance().is_valid(id))
		return SF_ERROR_INVALID_SENSOR_ID;

	if (!privilege)
		return SF_ERROR_INVALID_PARAM;

	info = sensor_info_manager::get_instance().get_info(id);
	if (!info)
		return SF_ERROR_GET_INFO_FAILED;

	sf_privilege = info->get_privilege();

	if (sf_privilege == SENSOR_PRIVILEGE_PUBLIC)
		*privilege = PUBLIC_PRIVILEGE_LIST;
	else if (sf_privilege == SENSOR_PRIVILEGE_INTERNAL)
		*privilege = INTERNAL_PRIVILEGE_LIST;

	return SF_SUCCESS;
}
