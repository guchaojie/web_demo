#ifndef __SF_SENSOR_DATA_H__
#define __SF_SENSOR_DATA_H__

#include <sensor_common.h>

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct sf_sensor_raw_data_s {
	void *raw;
	uint32_t size;
} sf_sensor_raw_data_t;

#define SLICE_DESC_SIZE 16
#define VALUE_COUNT 16

typedef struct sf_sensor_data_s {
	uint64_t time_stamp;
	uint32_t value_count;
	float values[VALUE_COUNT];
} sf_sensor_data_t;

typedef struct sf_sensor_hw_s {
	uint8_t bus_num;
	uint8_t sensor_address;
	uint8_t sensor_register;
} sf_sensor_hw_t;

typedef enum {
	SET_FIXED_DATA = 0,
	SET_RANDOM_DATA,
	SET_INC_DATA,
	SET_DEC_DATA,
} sf_set_data_method_t;

/* Sensor Data List */
int32_t sf_get_sensor_data(sf_sensor_id_t sensor_id, sf_sensor_data_t *sensor_data);
int32_t sf_get_sensor_raw_data(sf_sensor_id_t sensor_id, sf_sensor_raw_data_t *raw_data);
int32_t sf_set_sensor_data(sf_sensor_id_t sensor_id, sf_sensor_data_t sensor_data);
int32_t sf_set_sensor_data_read_method(sf_sensor_id_t sensor_id, sf_sensor_hw_t hw_info);

#ifdef __cplusplus
}
#endif

#endif /* __SF_SENSOR_DATA_H__ */
