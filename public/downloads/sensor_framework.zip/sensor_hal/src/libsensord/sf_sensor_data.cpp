#include <sf_sensor_data.h>
#include <sf_error.h>
#include <csensor_event_listener.h>
#include <sensor_info_manager.h>
#include <cmutex.h>
#include <client_common.h>
#include <command_channel.h>

#ifndef API
#define API __attribute__((visibility("default")))
#endif

extern csensor_event_listener &event_listener;
static cmutex lock;

API int32_t sf_get_sensor_data(sf_sensor_id_t sensor_id, sf_sensor_data_t *sensor_data)
{
	command_channel *cmd_channel;
	int sensor_state, handle;
	int client_id;

	if (!sensor_data)
		return SF_ERROR_INVALID_PARAM;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s",
					get_client_name(), get_sensor_name(sensor_id));
		return SF_ERROR_GET_CHANNEL_FAILED;
	}

	client_id = event_listener.get_client_id();
	if (client_id < 0) {
		ERR("Invalid client id : %d, handle: %d, %s, %s",
			client_id, handle, get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_GET_CLIENT_ID_FAILED;
	}

	if (sensor_state != SENSOR_STATE_STARTED) {
		ERR("Sensor %s is not started for client %s with handle: %d, sensor_state: %d",
			get_sensor_name(sensor_id), get_client_name(), handle, sensor_state);
		return SF_ERROR_SENSOR_NOT_START;
	}

	if(!cmd_channel->cmd_get_data(0, sensor_data)) {
		ERR("cmd_get_data(%d, 0x%x) failed for %s",
				client_id, sensor_data, get_client_name());
		return SF_ERROR_CMD_GET_DATA_FAILED;
	}

	return SF_SUCCESS;
}

API int32_t sf_set_sensor_data_read_method(sf_sensor_id_t sensor_id, sf_sensor_hw_t hw_info)
{
	command_channel *cmd_channel;
	int sensor_state, handle;
	int client_id;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s",
					get_client_name(), get_sensor_name(sensor_id));
		return SF_ERROR_GET_CHANNEL_FAILED;
	}

	client_id = event_listener.get_client_id();
	if (client_id < 0) {
		ERR("Invalid client id : %d, handle: %d, %s, %s",
			client_id, handle, get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_GET_CLIENT_ID_FAILED;
	}

	if (sensor_state != SENSOR_STATE_STARTED) {
		ERR("Sensor %s is not started for client %s with handle: %d, sensor_state: %d",
			get_sensor_name(sensor_id), get_client_name(), handle, sensor_state);
		return SF_ERROR_SENSOR_NOT_START;
	}

	if(!cmd_channel->cmd_set_read_method(hw_info)) {
		ERR("cmd_set_read_method(%d) failed for %s",
				client_id, get_client_name());
		return SF_ERROR_CMD_SET_READ_METHOD_FAILED;
	}

	return SF_SUCCESS;

}

API int32_t sf_get_sensor_raw_data(sf_sensor_id_t sensor_id, sf_sensor_raw_data_t *raw_data)
{
	command_channel *cmd_channel;
	int sensor_state, handle;
	int client_id;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s",
					get_client_name(), get_sensor_name(sensor_id));
		return SF_ERROR_GET_CHANNEL_FAILED;
	}

	client_id = event_listener.get_client_id();
	if (client_id < 0) {
		ERR("Invalid client id : %d, handle: %d, %s, %s",
			client_id, handle, get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_GET_CLIENT_ID_FAILED;
	}

	if (sensor_state != SENSOR_STATE_STARTED) {
		ERR("Sensor %s is not started for client %s with handle: %d, sensor_state: %d",
			get_sensor_name(sensor_id), get_client_name(), handle, sensor_state);
		return SF_ERROR_SENSOR_NOT_START;
	}

	if(!cmd_channel->cmd_get_raw_data(raw_data)) {
		ERR("cmd_get_raw_data(%d) failed for %s",
				client_id, get_client_name());
		return SF_ERROR_CMD_GET_RAW_DATA_FAILED;
	}

	return SF_SUCCESS;
}

API int32_t sf_set_sensor_data(sf_sensor_id_t sensor_id, sf_sensor_data_t sensor_data)
{
	command_channel *cmd_channel;
	int sensor_state, handle;
	int client_id;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	AUTOLOCK(lock);

	if (!event_listener.get_handle_id(sensor_id, handle)) {
		ERR("client %s failed to get handle information", get_client_name());
		return SF_ERROR_GET_HANDLE_FAILED;
	}

	if (!event_listener.get_sensor_state(handle, sensor_state)) {
		ERR("client %s failed to get sensor state information", get_client_name());
		return SF_ERROR_GET_STATE_FAILED;
	}

	if (!event_listener.get_command_channel(sensor_id, &cmd_channel)) {
		ERR("client %s failed to get command channel for %s",
					get_client_name(), get_sensor_name(sensor_id));
		return SF_ERROR_GET_CHANNEL_FAILED;
	}

	client_id = event_listener.get_client_id();
	if (client_id < 0) {
		ERR("Invalid client id : %d, handle: %d, %s, %s",
			client_id, handle, get_sensor_name(sensor_id), get_client_name());
		return SF_ERROR_GET_CLIENT_ID_FAILED;
	}

	if (sensor_state != SENSOR_STATE_STARTED) {
		ERR("Sensor %s is not started for client %s with handle: %d, sensor_state: %d",
			get_sensor_name(sensor_id), get_client_name(), handle, sensor_state);
		return SF_ERROR_SENSOR_NOT_START;
	}

	if(!cmd_channel->cmd_set_data(sensor_data)) {
		ERR("cmd_set_data(%d) failed for %s",
				client_id, get_client_name());
		return SF_ERROR_CMD_SET_DATA_FAILED;
	}

	return SF_SUCCESS;
}
