#include <string.h>
#include <sf_adapter.h>
#include <sensor_common.h>
#include <common.h>

void sf_sensorid_to_sensorid(const sf_sensor_id_t &sf_id, sensor_id_t &id)
{
	id = (sensor_id_t)sf_id;
}

void sensorid_to_sf_sensorid(const sensor_id_t &id, sf_sensor_id_t &sf_id)
{
	sf_id = (sf_sensor_id_t)id;
}

void sf_typeid_to_typeid(const sf_sensor_type_id_t &sf_typeid, sensor_type_id_t &tid)
{
	tid = (sf_sensor_type_id_t)sf_typeid;
}

void typeid_to_sf_typeid(const sensor_type_id_t &tid, sf_sensor_type_id_t &sf_typeid)
{
	sf_typeid = (sensor_type_id_t)tid;
}

void sensorinfo_to_sf_sensor(sensor_info info, sf_sensor_t &sf_sensor)
{
	sensor_id_t id = info.get_id();
	sensorid_to_sf_sensorid(id, sf_sensor.sensor_id);
	strcpy(sf_sensor.sensor_name, const_cast<char*>(info.get_name()));
}

bool check_type_name(sf_sensor_type_t type)
{
	int ret = false;

	if ((type.sensor_type_id == ACCELEROMETER_SENSOR) &&
	    (strcmp(type.sensor_type, "ACCELEROMETER_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == GEOMAGNETIC_SENSOR) &&
		 (strcmp(type.sensor_type, "GEOMAGNETIC_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == LIGHT_SENSOR) &&
		 (strcmp(type.sensor_type, "LIGHT_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == GYROSCOPE_SENSOR) &&
		 (strcmp(type.sensor_type, "GYROSCOPE_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == PRESSURE_SENSOR) &&
		 (strcmp(type.sensor_type, "PRESSURE_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == TEMPERATURE_SENSOR) &&
		 (strcmp(type.sensor_type, "TEMPERATURE_SENSOR") == 0))
		ret = true;
	else if ((type.sensor_type_id == MISC_SENSOR) &&
		 (strcmp(type.sensor_type, "MISC_SENSOR") == 0))
		ret = true;
	else {
		ERR("%s fail! type_id=%d sensor_type=%s", __func__, type.sensor_type_id, type.sensor_type);
		ret = false;
	}
	return ret;
}

