#ifndef __cplusplus
#define __cplusplus

#endif

#include <unistd.h>
#include <sf_sensor_type.h>
#include <sf_error.h>

#include <command_channel.h>
#include <sensor_info.h>
#include <sensor_info_manager.h>
#include <cbase_lock.h>
#include <cmutex.h>

#include <vector>

#ifndef API
#define API __attribute__((visibility("default")))
#endif

static bool get_sensor_list(void)
{
	static cmutex l;
	static bool init = false;
	
	AUTOLOCK(l);
	
	if (!init) {
		command_channel cmd_channel;
		
		if (!cmd_channel.create_channel()) {
			printf("%s failed to create command channel", get_client_name());
			return false;
		}
		
		if (!cmd_channel.cmd_get_sensor_list())
			return false;
		
		init = true;
	}
	
	return true;
}

API int32_t sf_get_sensor_type_count(uint32_t *count)
{
	int size;
	
	if (!count)
		return SF_ERROR_INVALID_PARAM;
	
	if (!get_sensor_list()) {
		printf("Fail to get sensor list from server");
		return SF_ERROR_CMD_GET_SENSOR_FAILED;
	}
	
	size = sensor_info_manager::get_instance().get_sensor_type_count();
	if (size < 0)
		return SF_ERROR_INVALID_TYPE_COUNT;
	
	*count = (uint32_t)size;
	
	return SF_SUCCESS;
}

API int32_t sf_get_sensor_type_list(uint32_t count, sf_sensor_type_t *type_list)
{
	int i, size;
	
	if (!type_list)
		return SF_ERROR_INVALID_PARAM;
	
	if (count == 0)
		return SF_ERROR_INVALID_PARAM;
	
	std::vector<sensor_info *> sensor_infos =
		sensor_info_manager::get_instance().get_sensor_type_list(&size);
	for (i = 0; i < (count < size ? count : size); i++) {
		type_list[i].sensor_type_id = sensor_infos[i]->get_type_id();
		strcpy(type_list[i].sensor_type, sensor_infos[i]->get_sensor_type());
	}
	
	return SF_SUCCESS;
}

API int32_t sf_sensor_type_is_supported(sf_sensor_type_t *type)
{
	int i, size;

	if (!type)
		return SF_ERROR_INVALID_PARAM;

	vector<sensor_info *> sensor_infos =
		sensor_info_manager::get_instance().get_sensor_type_list(&size);

	for (i = 0; i < size; i++) {
		if (!strncmp(type->sensor_type,
				sensor_infos[i]->get_sensor_type(),
				strlen(type->sensor_type))) {
				type->sensor_type_id =
				sensor_infos[i]->get_type_id();
			return SF_SUCCESS;
		}
	}

	return SF_ERROR_INVALID_SENSOR_TYPE;
}

API int32_t sf_get_type_of_sensor(sf_sensor_id_t sensor_id, sf_sensor_type_t *type)
{
	sensor_info *info;

	if (!type)
		return SF_ERROR_INVALID_PARAM;

	if (!sensor_info_manager::get_instance().is_valid(sensor_id))
		return SF_ERROR_INVALID_SENSOR_ID;

	info = sensor_info_manager::get_instance().get_info((sensor_id_t)sensor_id);
	if (!info)
		return SF_ERROR_GET_INFO_FAILED;

	type->sensor_type_id = info->get_type_id();
	strcpy(type->sensor_type, info->get_sensor_type());

	return SF_SUCCESS;

}

