#ifndef __SF_ERROR_H__
#define __SF_ERROR_H__

#ifdef __cplusplus
extern "C"
{
#endif


#define SF_ERROR_BASE                        ((int)0)

#define SF_SUCCESS                           ((int)0)

#define SF_ERROR_GET_INFO_FAILED             ((int)SF_ERROR_BASE - 0x01)
#define SF_ERROR_MAX_HANDLE_REACHED          ((int)SF_ERROR_BASE - 0x02)
#define SF_ERROR_CREATE_CHANNEL_FAILED       ((int)SF_ERROR_BASE - 0x03)
#define SF_ERROR_GET_CHANNEL_FAILED          ((int)SF_ERROR_BASE - 0x04)
#define SF_ERROR_GET_HANDLE_FAILED           ((int)SF_ERROR_BASE - 0x05)
#define SF_ERROR_GET_STATE_FAILED            ((int)SF_ERROR_BASE - 0x06)
#define SF_ERROR_GET_CLIENT_ID_FAILED        ((int)SF_ERROR_BASE - 0x07)
#define SF_ERROR_DELETE_HANDLE_FAILED        ((int)SF_ERROR_BASE - 0x08)

#define SF_ERROR_CMD_GET_ID_FAILED           ((int)SF_ERROR_BASE - 0x10)
#define SF_ERROR_CMD_HELLO_FAILED            ((int)SF_ERROR_BASE - 0x11)
#define SF_ERROR_CMD_START_FAILED            ((int)SF_ERROR_BASE - 0x12)
#define SF_ERROR_CMD_BYE_FAILED              ((int)SF_ERROR_BASE - 0x13)
#define SF_ERROR_CMD_STOP_FAILED             ((int)SF_ERROR_BASE - 0x14)
#define SF_ERROR_CMD_GET_SENSOR_FAILED       ((int)SF_ERROR_BASE - 0x15)
#define SF_ERROR_CMD_REG_SENSOR_FAILED       ((int)SF_ERROR_BASE - 0x16)
#define SF_ERROR_CMD_UNREG_SENSOR_FAILED     ((int)SF_ERROR_BASE - 0x17)
#define SF_ERROR_CMD_GET_DATA_FAILED         ((int)SF_ERROR_BASE - 0x18)
#define SF_ERROR_CMD_SET_READ_METHOD_FAILED  ((int)SF_ERROR_BASE - 0x19)
#define SF_ERROR_CMD_SET_DATA_FAILED         ((int)SF_ERROR_BASE - 0x1A)
#define SF_ERROR_CMD_GET_RAW_DATA_FAILED     ((int)SF_ERROR_BASE - 0x1B)

#define SF_ERROR_INVALID_PARAM               ((int)SF_ERROR_BASE - 0x20)
#define SF_ERROR_INVALID_SENSOR_ID           ((int)SF_ERROR_BASE - 0x21)
#define SF_ERROR_INVALID_SENSOR_SIZE         ((int)SF_ERROR_BASE - 0x22)
#define SF_ERROR_INVALID_SENSOR_DATA         ((int)SF_ERROR_BASE - 0x23)
#define SF_ERROR_INVALID_SENSOR_TYPE         ((int)SF_ERROR_BASE - 0x24)
#define SF_ERROR_INVALID_TYPE_COUNT          ((int)SF_ERROR_BASE - 0x25)

#define SF_ERROR_OUT_OF_MEMORY               ((int)SF_ERROR_BASE - 0x30)
#define SF_ERROR_SENSOR_NOT_START            ((int)SF_ERROR_BASE - 0x31)
#define SF_ERROR_SENSOR_IS_BUSY	             ((int)SF_ERROR_BASE - 0x32)

#define SF_ERROR_ACCESS_DENY                 ((int)SF_ERROR_BASE - 0x40)
#define SF_ERROR_PRIVILEGE_DENY              ((int)SF_ERROR_BASE - 0x41)

#ifdef __cplusplus
}
#endif

#endif /* __SF_ERROR_H__ */
