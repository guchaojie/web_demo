#ifndef __SF_TYPES_H__
#define __SF_TYPES_H__

//#ifdef __cplusplus
//extern "C"
//{
//#endif

typedef unsigned char	byte;
typedef unsigned short	word;
typedef unsigned int	dword;

typedef signed char		int8_t;
typedef signed short int	int16_t;
typedef signed int		int32_t;
typedef long long		int64_t;
typedef unsigned char		uint8_t;
typedef unsigned short int	uint16_t;
typedef unsigned int		uint32_t;
typedef unsigned long long	uint64_t;

typedef int8_t		s8;
typedef uint8_t		u8;
typedef int16_t		s16;
typedef uint16_t	u16;
typedef int32_t		s32;
typedef uint32_t	u32;
typedef int64_t		s64;
typedef uint64_t	u64;

//#ifdef __cplusplus
//}
//#endif

#endif /* __SF_TYPES_H__ */
