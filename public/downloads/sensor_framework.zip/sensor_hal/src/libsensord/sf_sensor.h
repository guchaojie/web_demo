#ifndef __SF_SENSOR_H__
#define __SF_SENSOR_H__

//#include <sf_types.h>
#include <sf_sensor_type.h>

#ifdef __cplusplus
extern "C"
{
#endif

//typedef uint32_t sf_sensor_id_t;

struct sf_sensor_type_s;

typedef struct sf_sensor_s {
	sf_sensor_id_t sensor_id;
	char sensor_name[SENSOR_NAME_SIZE];
	struct sf_sensor_type_s sensor_type;
} sf_sensor_t;

/*
 * Sensor Status.
 */
typedef enum {
	SF_SENSOR_UNKNOWN = 0,
	SF_SENSOR_READY,
	SF_SENSOR_RUNNING,
} sf_sensor_status_t;

/*
 * Sensor Interfaces.
 */

/**
 * @brief Register a new sensor into sensor framework.
 *
 * @param[in] name the name of the sesnor to be registered.
 * @param[in] type the type struct of the sensor to be registered.
 * @param[out] id the id of the register sensor.
 * @return SF_SUCCESS on success, otherwise the exact error num.
 */
int32_t sf_register_sensor(char *name, sf_sensor_type_t type, sf_sensor_id_t *id);

/**
 * @brief Unregister a exist sensor from sensor framework.
 *
 * @param[in] id the id of the sensor to be unregister.
 * @return SF_SUCCESS on success, otherwise the exact error num.
 */
int32_t sf_unregister_sensor(sf_sensor_id_t id);

/*
 * Get the sensor count of the specific sensor type.
 */
//bool sef_update_sensor_list(void);
int32_t sf_get_sensor_count(sf_sensor_type_t type, uint32_t *count);
//int32_t sf_get_sensor_list(sf_sensor_type_t type, int count, sf_sensor_id_t *ids);
int32_t sf_get_sensor_list(sf_sensor_type_t type, int count, sf_sensor_t *list);
int32_t sf_get_sensor_by_id(sf_sensor_id_t id, sf_sensor_t *sensor);
int32_t sf_get_default_sensor(sf_sensor_type_t type, sf_sensor_t *sensor);

/* Sensor Control Interfaces. */
int32_t sf_connect_sensor(sf_sensor_id_t sensor_id);
int32_t sf_disconnect_sensor(sf_sensor_id_t sensor_id);

int32_t sf_get_sensor_status(sf_sensor_id_t sensor_id, sf_sensor_status_t *status);
int32_t sf_get_sensor_name(sf_sensor_id_t id, const char **name);
int32_t sf_get_sensor_privilege(sf_sensor_id_t id,  const char **privilege);

#ifdef __cplusplus
}
#endif

#endif
