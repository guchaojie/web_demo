/*
 * sensord
 *
 * Copyright (c) 2015 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */
#include <time.h>
#include <glib.h>
#include <stdlib.h>
#include <stdio.h>
#include <sensor_internal.h>
#include <sf_sensor.h>
#include <sf_sensor_data.h>
#include <sf_sensor_type.h>
#include <stdbool.h>
#include <sensor_common.h>
#include <unistd.h>

#define DEFAULT_EVENT_INTERVAL 100

static GMainLoop *mainloop;
FILE *fp;

void callback(unsigned int event_type, sensor_event_data_t *event, void *user_data)
{
	g_main_loop_quit(mainloop);
}

bool check_register_sensor(void)
{
	char *name = "abcd";
	sf_sensor_type_t type = {MISC_SENSOR, "MISC_SENSOR"};
	sf_sensor_id_t id;
	int ret;

	int result;
	sf_sensor_t sensor;

	ret = sf_register_sensor(name, type, &id);
	fprintf(fp, "sf_register_sensor, id = 0x%x, ret = %d\n", id, ret);

	if (ret < 0) {
		fprintf(fp, "sf_register_sensor fail!\n", id, ret);
		return false;
	}

	result = sf_get_sensor_by_id(id, &sensor);
	if (result < 0) {
		fprintf(fp, "Invalid sensor id %d.\n", id);
	} else {
		fprintf(fp, "[%d] sensor:\n", id);
		fprintf(fp, "sensor id is 0x%x\n", sensor.sensor_id);
		fprintf(fp, "sensor name is %s\n", sensor.sensor_name);
		fprintf(fp, "sensor type id is %d\n", sensor.sensor_type.sensor_type_id);
		fprintf(fp, "sensor type is %s\n", sensor.sensor_type.sensor_type);
	}

	result = sf_connect_sensor(id);
	if (result <0) {
		fprintf(fp, "error: %d, failed to connect to sensor\n", result);
		return false;
	}

	fprintf(fp, "Connect to sensor id %d successfully!\n", id);

	ret = sf_unregister_sensor(id);
	fprintf(fp, "sf_unregister_sensor, ret = %d\n", ret);


	result = sf_disconnect_sensor(id);
	if (result <0) {
		fprintf(fp, "error: %d, failed to disconnect to sensor\n", result);
		return false;
	}
	fprintf(fp, "Disconnect to sensor id %d successfully!\n", id);

	ret = sf_unregister_sensor(id);
	fprintf(fp, "sf_unregister_sensor again, ret = %d\n", ret);

	return true;
}

bool dump_sensors()
{
/*
	bool result_boolean;
	int output;
	float value;
	sensor_t *output_list;
	sensor_type_support_t  sensor_type;
	sensor_id_t sensor_id;
	int i;

	output = 0;
	result_boolean = sensord_get_sensor_list(ALL_SENSOR, &output_list, &output);
	if (!result_boolean) {
		fprintf(fp, "Sensor failed at sensord_get_sensor_list\n");
		return false;
	}

	fprintf(fp, "Total sensors count:%d\n", output);

	for (i = 0; i < output; i++) {

		sensord_get_type(output_list[i], &sensor_type);
		fprintf(fp, "\nType:%d\n", sensor_type);
		sensord_get_id(output_list[i], &sensor_id);
		fprintf(fp, "ID:%d\n", sensor_id);
		fprintf(fp, "Name:%s\n", sensord_get_name(output_list[i]));
		fprintf(fp, "Vendor:%s\n", sensord_get_vendor(output_list[i]));

		sensord_get_min_range(output_list[i], &value);
		fprintf(fp, "Min_range:%f\n", value);

		sensord_get_max_range(output_list[i], &value);
		fprintf(fp, "Max_range:%f\n", value);

		sensord_get_resolution(output_list[i], &value);
		fprintf(fp, "Resolution:%f\n", value);
	}
*/
	return true;
}

bool check_sensor_api(unsigned int event_type, int cond_value)
{
//	int result, handle;
	int i, j, result;
	unsigned int count, total_types;
	uint8_t *p;
	const char *name, *privilege;
	char status_desc[10];
	sf_sensor_data_t data;
	sf_sensor_data_t set_data;
	sf_sensor_raw_data_t raw_data;
	sf_sensor_type_t *sensor_type_list;
	sf_sensor_type_t *sensor_support_type;
	sf_sensor_type_t *sensor_type;
	sf_sensor_t *sensor_list;
	sf_sensor_t sensor;
	sf_sensor_t default_sensor;
	sf_sensor_hw_t hw_info;
	sf_sensor_status_t status;

	mainloop = g_main_loop_new(NULL, FALSE);

	result = sf_get_sensor_type_count(&count);
	if (result < 0) {
		fprintf(fp, "error: %d, failed to get sensor type count\n", result);
		return false;
	}
	fprintf(fp, "sensor type count is %d\n", count);

	total_types = count;

	sensor_type_list = (sf_sensor_type_t *)malloc(count * sizeof(sf_sensor_type_t));

	result = sf_get_sensor_type_list(count, sensor_type_list);
	if (result < 0) {
		fprintf(fp, "error: %d, failed to get sensor type list\n", result);
		return false;
	}
	for (i = 0; i < count; i++) {
		fprintf(fp, "%d senor type id is %d ", i, sensor_type_list[i].sensor_type_id);
		fprintf(fp, "type name is %s\n", sensor_type_list[i].sensor_type);
	}

	// Test all sensors
	//total_types = 3;
	for (i = 0; i < total_types; i++) {
		result = sf_get_sensor_count(sensor_type_list[i], &count);
		if (result < 0) {
			fprintf(fp, "error: %d, failed to get sensor count\n", result);
			return false;
		}
		fprintf(fp, "%d sf_get_sensor_count type=%s count=%d\n", i, sensor_type_list[i].sensor_type, count);

		sensor_list = (sf_sensor_t *)malloc(count * sizeof(sf_sensor_t));
		result = sf_get_sensor_list(sensor_type_list[i], count, sensor_list);
		if (result < 0) {
			fprintf(fp, "error: %d, failed to get sensor list\n", result);
			return false;
		}
		for (j = 0; j < count; j++) {
			fprintf(fp, "No:%d sensor id is %d\n", j, sensor_list[j].sensor_id);
			fprintf(fp, "\t%d sensor name is %s\n", j, sensor_list[j].sensor_name);
			fprintf(fp, "\t%d type id is %d\n", j, sensor_list[j].sensor_type.sensor_type_id);
			fprintf(fp, "\t%d type is %s\n", j, sensor_list[j].sensor_type.sensor_type);
		}

		result = sf_get_default_sensor(sensor_type_list[i], &default_sensor);
		if (result < 0) {
			fprintf(fp, "error: %d, Fail to get default sensor.\n", result);
		} else {
			fprintf(fp, "sf_get_default_sensor %s default sensor:\n", sensor_type_list[i].sensor_type);
			fprintf(fp, "\tid is %d\n", default_sensor.sensor_id);
			fprintf(fp, "\tname is %s\n", default_sensor.sensor_name);
			fprintf(fp, "\ttype id is %d\n", default_sensor.sensor_type.sensor_type_id);
			fprintf(fp, "\ttype is %s\n", default_sensor.sensor_type.sensor_type);
		}

		result = sf_connect_sensor(default_sensor.sensor_id);
		if (result <0) {
			fprintf(fp, "error: %d, failed to connect to sensor\n", result);
			return false;
		}

		fprintf(fp, "Connect to %s sensor id %d successfully!\n",
				default_sensor.sensor_name, default_sensor.sensor_id);

		result = sf_get_sensor_data(default_sensor.sensor_id, &data);
		if (result < 0) {
			sf_disconnect_sensor(default_sensor.sensor_id);
			fprintf(fp, "error: %d, Sensor - %d, failed at sf_get_sensor_data\n", default_sensor.sensor_id);
			return false;
		}
		fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
		for (j = 0; j < data.value_count; j++) {
			fprintf(fp, "value %d: %f\n", j, data.values[j]);
		}

		//sleep(1);

		result = sf_get_sensor_data(default_sensor.sensor_id, &data);
		if (result < 0) {
			sf_disconnect_sensor(default_sensor.sensor_id);
			fprintf(fp, "error: %d, Sensor - %d, failed at sf_get_sensor_data\n", default_sensor.sensor_id);
			return false;
		}
		fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
		for (j = 0; j < data.value_count; j++) {
			fprintf(fp, "value %d: %f\n", j, data.values[j]);
		}

		// set & get data test for one circle
			set_data.time_stamp = i + 1;
			set_data.value_count = i + 2;
			for (j = 0; j < set_data.value_count; j++) {
				set_data.values[j] = j*j;
			}
			result = sf_set_sensor_data(default_sensor.sensor_id, set_data);
			if (result < 0) {
				sf_disconnect_sensor(default_sensor.sensor_id);
				fprintf(fp, "Sensor[%d], failed at sf_set_sensor_data ret=%d\n", default_sensor.sensor_id, result);
				return false;
			}
			fprintf(fp, "***sf_set_sensor_data successfully value_count=%d\n", set_data.value_count);

			result = sf_get_sensor_data(default_sensor.sensor_id, &data);
			if (result < 0) {
				sf_disconnect_sensor(default_sensor.sensor_id);
				fprintf(fp, "Sensor - %d, failed at sf_get_sensor_data\n", default_sensor.sensor_id);
				return false;
			}
			fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
			for (j = 0; j < data.value_count; j++) {
				fprintf(fp, "value %d: %f\n", j, data.values[j]);
			}
		// get data back to orignal state
			result = sf_get_sensor_data(default_sensor.sensor_id, &data);
			if (result < 0) {
				sf_disconnect_sensor(default_sensor.sensor_id);
				fprintf(fp, "Sensor - %d, failed at sf_get_sensor_data\n", default_sensor.sensor_id);
				return false;
			}
			fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
			for (j = 0; j < data.value_count; j++) {
				fprintf(fp, "value %d: %f\n", j, data.values[j]);
			}

		result = sf_disconnect_sensor(default_sensor.sensor_id);
		if (result <0) {
			fprintf(fp, "error: %d, failed to disconnect to sensor\n", result);
			return false;
		}

		fprintf(fp, "Disconnect to %s sensor id %d successfully!\n",
					default_sensor.sensor_name, default_sensor.sensor_id);

		free(sensor_list);
	}

	sensor_list = (sf_sensor_t *)malloc(count * sizeof(sf_sensor_t));

	result = sf_get_sensor_list(sensor_type_list[2], count, sensor_list);
	if (result < 0) {
		fprintf(fp, "error: %d, failed to get sensor list\n", result);
		return false;
	}
	for (i = 0; i < count; i++) {
		fprintf(fp, "sf_get_sensor_list No:%d sensor id is %d\n", i, sensor_list[i].sensor_id);
		fprintf(fp, "%d sensor name is %s\n", i, sensor_list[i].sensor_name);
		fprintf(fp, "%d type id is %d\n", i, sensor_list[i].sensor_type.sensor_type_id);
		fprintf(fp, "%d type is %s\n", i, sensor_list[i].sensor_type.sensor_type);
	}

	result = sf_get_default_sensor(sensor_type_list[0], &default_sensor);
	if (result < 0) {
		fprintf(fp, "error: %d, Fail to get default sensor.\n", result);
	} else {
		fprintf(fp, "sf_get_default_sensor %s default sensor:\n", sensor_type_list[0].sensor_type);
		fprintf(fp, "\tid is %d\n", default_sensor.sensor_id);
		fprintf(fp, "\tname is %s\n", default_sensor.sensor_name);
		fprintf(fp, "\ttype id is %d\n", default_sensor.sensor_type.sensor_type_id);
		fprintf(fp, "\ttype is %s\n", default_sensor.sensor_type.sensor_type);
	}

	i = sensor_list[0].sensor_id;
	result = sf_get_sensor_by_id(i, &sensor);
	if (result < 0) {
		fprintf(fp, "Invalid sensor id %d.\n", i);
	} else {
		fprintf(fp, "sf_get_sensor_by_id [%d] sensor:\n", i);
		fprintf(fp, "\tid is %d\n", sensor.sensor_id);
		fprintf(fp, "\tname is %s\n", sensor.sensor_name);
		fprintf(fp, "\ttype id is %d\n", sensor.sensor_type.sensor_type_id);
		fprintf(fp, "\ttype is %s\n", sensor.sensor_type.sensor_type);
	}

	sensor_support_type = (sf_sensor_type_t *)malloc(sizeof(sf_sensor_type_t));
	strcpy(sensor_support_type->sensor_type, sensor.sensor_type.sensor_type);

	result = sf_sensor_type_is_supported(sensor_support_type);
	if (result < 0) {
		fprintf(fp, "error: %d, failed to check sensor type is supported\n", result);
		return false;
	}
	fprintf(fp, "%s sensor type is supported , the sensor type id is %d\n",
			sensor_support_type->sensor_type, sensor_support_type->sensor_type_id);

	sensor_type = (sf_sensor_type_t *)malloc(sizeof(sf_sensor_type_t));

	result = sf_get_type_of_sensor(sensor_list[0].sensor_id, sensor_type);
	if (result < 0) {
		fprintf(fp, "error: %d, failed to get sensor type by sensor id\n", result);
		return false;
	}
	fprintf(fp, "sf_get_type_of_sensor sensor id %d type name is %s ", sensor_list[0].sensor_id, sensor_type->sensor_type);
	fprintf(fp, "sensor id %d type id is %d\n", sensor_list[0].sensor_id, sensor_type->sensor_type_id);

	result = sf_get_sensor_name(sensor_list[0].sensor_id, &name);
	if (result <0) {
		fprintf(fp, "error: %d, failed to get sensor name\n", result);
		return false;
	}
	fprintf(fp, "sf_get_sensor_name sensor id %d get name is %s\n", sensor_list[0].sensor_id, name);

	result = sf_get_sensor_privilege(sensor_list[0].sensor_id, &privilege);
	if (result <0) {
		fprintf(fp, "error: %d, failed to get sensor name\n", result);
		return false;
	}
	fprintf(fp, "sensor id %d get privilege is %s\n", sensor_list[0].sensor_id, privilege);

	result = sf_connect_sensor(sensor_list[0].sensor_id);
	if (result <0) {
		fprintf(fp, "error: %d, failed to connect to sensor\n", result);
		return false;
	}

	fprintf(fp, "Connect to %s sensor id %d successfully!\n",
				sensor_list[0].sensor_name, sensor_list[0].sensor_id);

	result = sf_get_sensor_data(sensor_list[0].sensor_id, &data);
	if (result < 0) {
		sf_disconnect_sensor(sensor_list[0].sensor_id);
		fprintf(fp, "error: %d, Sensor - %d, failed at sf_get_sensor_data\n", sensor_list[0].sensor_id);
		return false;
	}
	fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
	for (i = 0; i < data.value_count; i++) {
		fprintf(fp, "value %d: %f\n", i, data.values[i]);
	}

	result = sf_get_sensor_status(sensor_list[0].sensor_id, &status);
	if (result <0) {
		fprintf(fp, "error: %d, failed to get sensor status\n", result);
		return false;
	}
	if (status == SF_SENSOR_READY)
		strcpy(status_desc, "SF_SENSOR_READY");
	else if (status == SF_SENSOR_RUNNING)
		strcpy(status_desc, "SF_SENSOR_RUNNING");
	fprintf(fp, "sensor id %d get status is %s\n", sensor_list[0].sensor_id, status_desc);

// set & get data test for one circle
	set_data.time_stamp = 708970;
	set_data.value_count = 10;
	for (i = 0; i < set_data.value_count; i++) {
		set_data.values[i] = i*i;
	}
	result = sf_set_sensor_data(sensor_list[0].sensor_id, set_data);
	if (result < 0) {
		sf_disconnect_sensor(sensor_list[0].sensor_id);
		fprintf(fp, "Sensor[%d], failed at sf_set_sensor_data ret=%d\n", sensor_list[0].sensor_id, result);
		return false;
	}
	fprintf(fp, "sf_set_sensor_data successfully value_count=%d\n", set_data.value_count);

	result = sf_get_sensor_data(sensor_list[0].sensor_id, &data);
	if (result < 0) {
		sf_disconnect_sensor(sensor_list[0].sensor_id);
		fprintf(fp, "Sensor - %d, failed at sf_get_sensor_data\n", sensor_list[0].sensor_id);
		return false;
	}
	fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
	for (i = 0; i < data.value_count; i++) {
		fprintf(fp, "value %d: %f\n", i, data.values[i]);
	}
// get data back to orignal state
	result = sf_get_sensor_data(sensor_list[0].sensor_id, &data);
	if (result < 0) {
		sf_disconnect_sensor(sensor_list[0].sensor_id);
		fprintf(fp, "Sensor - %d, failed at sf_get_sensor_data\n", sensor_list[0].sensor_id);
		return false;
	}
	fprintf(fp, "sf_get_sensor_data count=%d timestamp=%llu\n", data.value_count, data.time_stamp);
	for (i = 0; i < data.value_count; i++) {
		fprintf(fp, "value %d: %f\n", i, data.values[i]);
	}

	hw_info.bus_num = 8;
	hw_info.sensor_address = 0x77;
	hw_info.sensor_register =0xd0;
	result = sf_set_sensor_data_read_method(sensor_list[0].sensor_id, hw_info);
	if (result <0) {
		fprintf(fp, "error: %d, failed to set sensor data read method\n", result);
		return false;
	}
	fprintf(fp, "%s sensor id %d set read raw data method successfully!\n",
				sensor_list[0].sensor_name, sensor_list[0].sensor_id);

	raw_data.size = 10;
	raw_data.raw = (uint8_t *)malloc(sizeof(uint8_t)*10);
	result = sf_get_sensor_raw_data(sensor_list[0].sensor_id, &raw_data);
	if (result <0) {
		fprintf(fp, "error: %d, failed to get sensor raw data\n", result);
		return false;
	}
	p = raw_data.raw;
	for (i = 0; i < raw_data.size; i++) {
		fprintf(fp, "raw value %d: 0x%02x\n", i, *p);
		p++;
	}

	result = sf_disconnect_sensor(sensor_list[0].sensor_id);
	if (result <0) {
		fprintf(fp, "error: %d, failed to disconnect to sensor\n", result);
		return false;
	}
	fprintf(fp, "Disconnect to %s sensor id %d successfully!\n",
				sensor_list[0].sensor_name, sensor_list[0].sensor_id);

	free(sensor_type);
	free(sensor_support_type);
	free(sensor_type_list);
	free(sensor_list);
#if 0
	sensor_type_t sensor_type = event_type >> 16;
	sensor_t sensor = sensord_get_sensor(sensor_type);

	handle = sensord_connect(sensor);

	if (handle < 0) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_connect\n", sensor_type, event_type);
		return false;
	}

	bool is_supported;
	bool result_boolean = sensord_is_supported_event_type(sensor, event_type, &is_supported);
	if (!result_boolean && !is_supported) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_is_supported_event\n", sensor_type, event_type);
		return false;
	}

	int output;
	result_boolean = sensord_get_min_interval(sensor, &output);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_min_interval\n", sensor_type, event_type);
		return false;
	}

	float output3;
	result_boolean = sensord_get_resolution(sensor, &output3);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_resolution\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_get_max_range(sensor, &output3);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_max_range\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_get_min_range(sensor, &output3);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_min_range\n", sensor_type, event_type);
		return false;
	}

	sensor_privilege_t output4;
	result_boolean = sensord_get_privilege(sensor, &output4);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_privilege\n", sensor_type, event_type);
		return false;
	}

	const char* result_char = sensord_get_vendor(sensor);
	if (!result_char) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_vendor\n", sensor_type, event_type);
		return false;
	}

	result_char = sensord_get_name(sensor);
	if (!result_char) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_name\n", sensor_type, event_type);
		return false;
	}

	sensor_type_t output_type;
	result_boolean = sensord_get_type(sensor, &output_type);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_type\n", sensor_type, event_type);
		return false;
	}

	unsigned int *output2;
	result_boolean = sensord_get_supported_event_types(sensor, &output2, &output);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_supported_event_types\n", sensor_type, event_type);
		return false;
	}

	sensor_t *output_list;
	result_boolean = sensord_get_sensor_list(sensor_type, &output_list, &output);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_sensor_list\n", sensor_type, event_type);
		return false;
	}

	result = sensord_register_event(handle, event_type, cond_value, 0, callback, NULL);

	if (result < 0) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_register_event\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_start(handle, 1);

	if (!result_boolean) {
		sensord_unregister_event(handle, event_type);
		sensord_disconnect(handle);
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_start\n", sensor_type, event_type);
		return false;
	}

	sensor_data_t data;
	result_boolean = sensord_get_data(handle, event_type, &data);
	if (!result_boolean) {
		sensord_unregister_event(handle, event_type);
		sensord_disconnect(handle);
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_get_data\n", sensor_type, event_type);
		return false;
	}

	g_main_loop_run(mainloop);
	g_main_loop_unref(mainloop);

	result_boolean = sensord_change_event_interval(handle, event_type, 101);
	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_change_event_interval\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_set_option(handle, SENSOR_OPTION_ON_IN_SCREEN_OFF);
	if (!result_boolean){
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_change_sensor_option\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_unregister_event(handle, event_type);

	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_unregister_event\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_stop(handle);

	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_stop\n", sensor_type, event_type);
		return false;
	}

	result_boolean = sensord_disconnect(handle);

	if (!result_boolean) {
		fprintf(fp, "Sensor - %d, event - %d, failed at sensord_disconnect\n", sensor_type, event_type);
		return false;
	}

#endif
	return true;
}

int main(int argc, char **argv)
{
	bool result;

	int interval = DEFAULT_EVENT_INTERVAL;
	if (argc == 2)
		interval = atof(argv[1]);

	fp = fopen("auto_test.output", "w+");

	//dump_sensors();

	result = check_sensor_api(GEOMAGNETIC_RAW_DATA_EVENT, interval);
	fprintf(fp, "check sensor api end!!\n");
	check_register_sensor();
	//sensord_get_sensor(1);
#if 0
	result = check_sensor_api(ACCELEROMETER_RAW_DATA_EVENT, interval);
	fprintf(fp, "Accelerometer - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(PRESSURE_RAW_DATA_EVENT, interval);
	fprintf(fp, "Pressure - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(TEMPERATURE_RAW_DATA_EVENT, interval);
	fprintf(fp, "Temperature - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(GYROSCOPE_RAW_DATA_EVENT, interval);
	fprintf(fp, "Gyroscope - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(GRAVITY_RAW_DATA_EVENT, interval);
	fprintf(fp, "Gravity - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(LIGHT_LUX_DATA_EVENT, interval);
	fprintf(fp, "Light - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(LINEAR_ACCEL_RAW_DATA_EVENT, interval);
	fprintf(fp, "Linear Accel - RAW_DATA_REPORT_ON_TIME - %d\n", result);

	result = check_sensor_api(ORIENTATION_RAW_DATA_EVENT, interval);
	fprintf(fp, "Orientation - RAW_DATA_REPORT_ON_TIME - %d\n", result);



	result = check_sensor_api(ROTATION_VECTOR_RAW_DATA_EVENT, interval);
	fprintf(fp, "Rotation Vector - RAW_DATA_REPORT_ON_TIME - %d\n", result);


	result = check_sensor_api(GAMING_RV_RAW_DATA_EVENT, interval);
	fprintf(fp, "Gaming Rotation Vector - RAW_DATA_REPORT_ON_TIME - %d\n", result);

#endif

	printf("Logs printed in ./auto_test.output\n");
	fclose(fp);
	return 0;
}
